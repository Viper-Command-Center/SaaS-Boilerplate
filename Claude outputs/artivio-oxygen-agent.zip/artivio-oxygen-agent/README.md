# Artivio Oxygen Agent

A snapshot-and-restore safety net for AI agents editing Oxygen Builder
pages, plus a version-drift warning. Built after the Test 1-6
investigation (2026-09-09, build2.churchwebglobal.com) found that
Oxygen's own MCP abilities already handle content and design writes
correctly once the right tool is used — so this plugin does NOT
reimplement Oxygen's write path. What it adds is the one thing nothing
in the stack had: **undo.**

## Why this is small

This was originally going to mirror `artivio-elementor-agent` — a full
tree read/write wrapper around Oxygen's data. That turned out to be
unnecessary. `oxygen-edit-post`, `oxygen-set-element-variable-overrides`,
and `oxygen-insert-stylesheet` work correctly; the design-properties
"bug" from earlier tonight was actually a wrong-tool problem, not a
broken write path. Reimplementing that path here would just be a second,
redundant way to corrupt the same data. See the plugin's own docblock
for the full reasoning.

## Install

Same as the other Artivio plugins: upload to `wp-content/plugins/`,
activate, no settings page. Authenticates the same way as any WP REST
call (Application Password over Basic Auth).

## Endpoints

- `GET /wp-json/artivio-oxygen/v1/status`
  Plugin version, detected Oxygen version, and whether that version has
  drifted from `ARTIVIO_OXYGEN_AGENT_VERIFIED_AGAINST` (the version this
  plugin and the current playbook were last checked against). Oxygen
  6.2 ships roughly one beta a week — this makes that drift visible
  instead of silently trusting week-old findings.

- `POST /wp-json/artivio-oxygen/v1/snapshot/{post_id}` (body: `label`
  optional) — captures this post's full postmeta set plus
  post_content/post_title, right now. Call this immediately before any
  risky Oxygen write (a design change, a structural edit) — it's the
  point you'd want to come back to if the write goes wrong.

- `GET /wp-json/artivio-oxygen/v1/snapshots/{post_id}` — lists this
  post's snapshots, newest first, with id/timestamp/label/Oxygen version
  at time of capture. Capped at 20 per post; oldest drop off first.

- `POST /wp-json/artivio-oxygen/v1/restore/{post_id}` (body:
  `snapshot_id`) — restores the post to exactly that snapshot's state.
  Always takes a fresh "pre-restore" snapshot of the current state
  first, so a restore is itself always undoable — there's no dead end.

## Recommended agent workflow

1. Before a risky Oxygen write: `POST /snapshot/{post_id}`.
2. Make the write via Oxygen's own MCP ability (content edit, variable
   override, stylesheet insert — whichever is correct for the job).
3. Verify with the audit plugin (`oxygen-audit-page`,
   `verify-variable-override`, etc.) — a `success: true` from the write
   is not proof it rendered; see that plugin's own notes.
4. If verification fails: `POST /restore/{post_id}` with the snapshot id
   from step 1.

## Honest limitations

- Covers per-post state only (postmeta + post_content + post_title).
  Does NOT cover site-wide state — a global CSS variable, a shared
  selector, a template assignment changed while editing this post is
  outside what a post-level restore can undo.
- Restoring does not repair Oxygen's internal consistency; it puts back
  exactly the bytes captured at snapshot time. If Oxygen's data format
  itself changed between snapshot and restore (e.g. a beta update
  happened in between), an old snapshot could hand a newer Oxygen
  version data it no longer expects. `/restore` reports whether the
  Oxygen version has drifted since the snapshot was taken — treat that
  warning seriously before relying on the restored result.
- This is a mistake safety net, not version control. Snapshots live in
  this site's own database, capped at 20 per post — not a substitute
  for real backups (which is how tonight's testing was made safe to do
  at all).

## Changelog

**1.0.0** — Initial release. Snapshot/list/restore, version-drift check
in `/status`.
