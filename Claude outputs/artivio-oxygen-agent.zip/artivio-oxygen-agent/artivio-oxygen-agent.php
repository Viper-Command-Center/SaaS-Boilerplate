<?php
/**
 * Plugin Name:       Artivio Oxygen Agent
 * Description:       Snapshot-and-restore safety net for AI agents editing Oxygen Builder pages, plus a version-drift warning since Oxygen 6.2 ships a new beta roughly every week.
 * Version:           1.0.0
 * Author:            Artivio
 * Requires PHP:      7.4
 *
 * ---------------------------------------------------------------------------
 * WHY THIS EXISTS, AND WHY IT'S SMALLER THAN ORIGINALLY PLANNED
 * ---------------------------------------------------------------------------
 * This was originally scoped as a full write-path wrapper around Oxygen's
 * own MCP abilities (mirroring artivio-elementor-agent's `_elementor_data`
 * tree read/write). The Test 1-6 investigation on build2.churchwebglobal.com
 * (2026-09-09) found that was unnecessary: Oxygen's own registered
 * abilities (`oxygen-edit-post`, `oxygen-set-element-variable-overrides`,
 * `oxygen-insert-stylesheet`, etc.) already handle content and design
 * writes correctly once the RIGHT tool is called for the right job — see
 * that investigation's conclusion: content -> oxygen-edit-post content.*,
 * scoped design -> oxygen-set-element-variable-overrides, reusable classes
 * -> oxygen-insert-stylesheet. There was no serialization bug to route
 * around. Reimplementing that write path here would only add a second,
 * redundant way to corrupt the same data.
 *
 * What tonight's investigation did NOT find anywhere in the stack: any
 * form of undo. A bad write from any of the above tools is only
 * recoverable via a full database backup. That's the actual gap this
 * plugin closes — a lightweight, manual snapshot/restore of a post's full
 * meta state, callable by an agent immediately before a risky write and
 * used to recover if the audit plugin's post-write verification
 * (`oxygen-audit-page`, `verify-variable-override`, etc.) comes back bad.
 *
 * ---------------------------------------------------------------------------
 * DESIGN PRINCIPLE: THIS MUST SURVIVE ORACLE'S — SORRY, OXYGEN'S — WEEKLY
 * BETA CADENCE
 * ---------------------------------------------------------------------------
 * Oxygen 6.2 has shipped roughly one beta per week since late July 2026.
 * This plugin deliberately does NOT know or assume anything about
 * Oxygen's internal data format (which meta keys it uses, how a tree is
 * shaped, how a variable override is serialized). Snapshot/restore
 * operates on a post's ENTIRE postmeta set plus post_content/post_title,
 * generically — whatever Oxygen is storing today, this captures and can
 * put back, without needing to be updated when Oxygen's internal schema
 * changes. The one thing that DOES need to be updated periodically is
 * ARTIVIO_OXYGEN_AGENT_VERIFIED_AGAINST below; `/status` compares it to
 * the live Oxygen version and says plainly when the two have drifted,
 * rather than silently assuming last week's findings still hold.
 *
 * ---------------------------------------------------------------------------
 * HONEST LIMITATIONS
 * ---------------------------------------------------------------------------
 * - Snapshot/restore covers postmeta + post_content + post_title. It does
 *   NOT cover site-wide state (global CSS variables set outside this post,
 *   selector definitions shared across the site, template assignments).
 *   Restoring a post's snapshot cannot undo a change to a GLOBAL variable
 *   or selector made while editing that post — only per-post state.
 * - Restoring does not attempt to understand or repair Oxygen's internal
 *   consistency; it puts back exactly the bytes that existed at snapshot
 *   time. If Oxygen itself changed its data format between the snapshot
 *   and the restore (e.g. a beta upgrade happened in between), restoring
 *   an old-format snapshot could hand Oxygen data it no longer expects.
 *   Check `/status` for version drift before restoring an old snapshot.
 * - This is a safety net for MISTAKES, not a version control system.
 *   Snapshots are capped (default 20 per post, oldest pruned) and stored
 *   in this site's own database — they are not a substitute for real
 *   backups.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ARTIVIO_OXYGEN_AGENT_VERSION', '1.0.0' );
define( 'ARTIVIO_OXYGEN_AGENT_NS', 'artivio-oxygen/v1' );

// The Oxygen version this plugin's assumptions (and the playbook it backs)
// were last verified against. Update this deliberately after each round of
// testing — it is what makes version drift visible instead of silent.
define( 'ARTIVIO_OXYGEN_AGENT_VERIFIED_AGAINST', '6.2.0-beta.8' );

define( 'ARTIVIO_OXYGEN_AGENT_SNAPSHOT_META_KEY', '_artivio_oxygen_snapshot_history' );
define( 'ARTIVIO_OXYGEN_AGENT_MAX_SNAPSHOTS', 20 );

/* ══════════════════════════════════════════════════════════════════════════
 * Permissions
 * ══════════════════════════════════════════════════════════════════════════ */

function artivio_oa_guard_post( int $post_id ) {
	if ( ! get_post( $post_id ) ) {
		return new WP_Error( 'artivio_oa_not_found', 'No post with that id.', array( 'status' => 404 ) );
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return new WP_Error( 'artivio_oa_forbidden', 'This user cannot edit that post.', array( 'status' => 403 ) );
	}
	return true;
}

function artivio_oa_can_edit(): bool {
	return current_user_can( 'edit_posts' );
}

/* ══════════════════════════════════════════════════════════════════════════
 * Oxygen version detection (read-only, no dependency on Oxygen internals
 * beyond the version constants it already defines for itself)
 * ══════════════════════════════════════════════════════════════════════════ */

function artivio_oa_detected_oxygen_version() {
	if ( defined( 'OXYGEN_VERSION' ) ) {
		return OXYGEN_VERSION;
	}
	if ( defined( 'CT_VERSION' ) ) {
		return CT_VERSION . ' (Classic)';
	}
	return null;
}

/* ══════════════════════════════════════════════════════════════════════════
 * Snapshot storage
 *
 * A snapshot is a full copy of get_post_meta($id) (every key, every value,
 * raw — not just Oxygen-looking keys, deliberately, since we do not want
 * to guess which keys matter and be wrong about it on the next beta) plus
 * post_content and post_title. Snapshots live in their own meta key as a
 * capped, timestamped array — not a WordPress core revision, so they are
 * not affected by revision-pruning settings and won't clutter the normal
 * revisions UI.
 * ══════════════════════════════════════════════════════════════════════════ */

function artivio_oa_get_history( int $post_id ): array {
	$raw = get_post_meta( $post_id, ARTIVIO_OXYGEN_AGENT_SNAPSHOT_META_KEY, true );
	return is_array( $raw ) ? $raw : array();
}

function artivio_oa_save_history( int $post_id, array $history ): void {
	update_post_meta( $post_id, ARTIVIO_OXYGEN_AGENT_SNAPSHOT_META_KEY, $history );
}

/**
 * Take a snapshot right now. Returns the new snapshot's id.
 */
function artivio_oa_take_snapshot( int $post_id, string $label = '' ): string {
	$post = get_post( $post_id );

	$meta = array();
	foreach ( get_post_meta( $post_id ) as $key => $values ) {
		// Don't snapshot our own snapshot history into itself.
		if ( ARTIVIO_OXYGEN_AGENT_SNAPSHOT_META_KEY === $key ) {
			continue;
		}
		$meta[ $key ] = $values; // get_post_meta($id) with no key returns arrays of raw (serialized-safe) strings per key.
	}

	$snapshot = array(
		'id'             => wp_generate_uuid4(),
		'timestamp'      => current_time( 'mysql', true ),
		'label'          => $label,
		'post_title'     => $post ? $post->post_title : '',
		'post_content'   => $post ? $post->post_content : '',
		'oxygen_version' => artivio_oa_detected_oxygen_version(),
		'meta'           => $meta,
	);

	$history   = artivio_oa_get_history( $post_id );
	$history[] = $snapshot;

	// Cap: keep the most recent N, oldest dropped first.
	if ( count( $history ) > ARTIVIO_OXYGEN_AGENT_MAX_SNAPSHOTS ) {
		$history = array_slice( $history, -1 * ARTIVIO_OXYGEN_AGENT_MAX_SNAPSHOTS );
	}

	artivio_oa_save_history( $post_id, $history );

	return $snapshot['id'];
}

function artivio_oa_find_snapshot( array $history, string $snapshot_id ) {
	foreach ( $history as $snap ) {
		if ( $snap['id'] === $snapshot_id ) {
			return $snap;
		}
	}
	return null;
}

/**
 * Restore a post to exactly the state a snapshot captured.
 *
 * Safety: takes a fresh "pre-restore" snapshot FIRST, so restoring is
 * itself always undoable — a bad restore is just another snapshot to
 * restore away from, never a dead end.
 */
function artivio_oa_restore_snapshot( int $post_id, string $snapshot_id ) {
	$history  = artivio_oa_get_history( $post_id );
	$snapshot = artivio_oa_find_snapshot( $history, $snapshot_id );
	if ( ! $snapshot ) {
		return new WP_Error( 'artivio_oa_no_snapshot', 'No snapshot with that id for this post.', array( 'status' => 404 ) );
	}

	$pre_restore_id = artivio_oa_take_snapshot( $post_id, 'auto: state immediately before restoring to ' . $snapshot_id );

	// Remove every current meta key not present in the snapshot, so this is
	// a true point-in-time restore rather than a merge (a key added after
	// the snapshot was taken would otherwise linger and contaminate it).
	$current_keys   = array_keys( get_post_meta( $post_id ) );
	$snapshot_keys  = array_keys( $snapshot['meta'] );
	$keys_to_remove = array_diff( $current_keys, $snapshot_keys, array( ARTIVIO_OXYGEN_AGENT_SNAPSHOT_META_KEY ) );
	foreach ( $keys_to_remove as $key ) {
		delete_post_meta( $post_id, $key );
	}

	foreach ( $snapshot['meta'] as $key => $values ) {
		delete_post_meta( $post_id, $key );
		foreach ( (array) $values as $value ) {
			// $value here is whatever get_post_meta returned earlier for this
			// key — already unslashed/unserialized by WP on the way out, so
			// add_post_meta will re-serialize/re-slash correctly on the way
			// back in without double-encoding.
			add_post_meta( $post_id, $key, $value );
		}
	}

	wp_update_post(
		array(
			'ID'           => $post_id,
			'post_title'   => $snapshot['post_title'],
			'post_content' => $snapshot['post_content'],
		)
	);

	clean_post_cache( $post_id );
	// Let any other plugin (e.g. a future cache-clearing addition) hook in
	// without this plugin needing to know Oxygen's specific cache internals.
	do_action( 'artivio_oxygen_agent_after_restore', $post_id, $snapshot );

	return array(
		'restored_snapshot_id' => $snapshot_id,
		'pre_restore_snapshot_id' => $pre_restore_id,
		'snapshot_taken_at'    => $snapshot['timestamp'],
		'snapshot_oxygen_version' => $snapshot['oxygen_version'],
		'current_oxygen_version'  => artivio_oa_detected_oxygen_version(),
		'note' => ( $snapshot['oxygen_version'] !== artivio_oa_detected_oxygen_version() )
			? 'WARNING: this snapshot was taken under a different Oxygen version than is currently active. See plugin docblock limitations — Oxygen may not expect this data shape.'
			: 'Snapshot and current Oxygen version match.',
	);
}

/* ══════════════════════════════════════════════════════════════════════════
 * Routes
 * ══════════════════════════════════════════════════════════════════════════ */

add_action( 'rest_api_init', 'artivio_oa_register_routes' );

function artivio_oa_register_routes() {
	register_rest_route(
		ARTIVIO_OXYGEN_AGENT_NS,
		'/status',
		array(
			'methods'             => 'GET',
			'permission_callback' => 'artivio_oa_can_edit',
			'callback'            => 'artivio_oa_status',
		)
	);

	register_rest_route(
		ARTIVIO_OXYGEN_AGENT_NS,
		'/snapshot/(?P<id>\d+)',
		array(
			'methods'             => 'POST',
			'permission_callback' => 'artivio_oa_can_edit',
			'callback'            => 'artivio_oa_route_snapshot',
			'args'                => array(
				'id' => array(
					'validate_callback' => function ( $param ) {
						return is_numeric( $param );
					},
				),
				'label' => array( 'required' => false ),
			),
		)
	);

	register_rest_route(
		ARTIVIO_OXYGEN_AGENT_NS,
		'/snapshots/(?P<id>\d+)',
		array(
			'methods'             => 'GET',
			'permission_callback' => 'artivio_oa_can_edit',
			'callback'            => 'artivio_oa_route_list_snapshots',
			'args'                => array(
				'id' => array(
					'validate_callback' => function ( $param ) {
						return is_numeric( $param );
					},
				),
			),
		)
	);

	register_rest_route(
		ARTIVIO_OXYGEN_AGENT_NS,
		'/restore/(?P<id>\d+)',
		array(
			'methods'             => 'POST',
			'permission_callback' => 'artivio_oa_can_edit',
			'callback'            => 'artivio_oa_route_restore',
			'args'                => array(
				'id' => array(
					'validate_callback' => function ( $param ) {
						return is_numeric( $param );
					},
				),
				'snapshot_id' => array( 'required' => true ),
			),
		)
	);
}

function artivio_oa_status() {
	$detected = artivio_oa_detected_oxygen_version();
	$verified = ARTIVIO_OXYGEN_AGENT_VERIFIED_AGAINST;
	return array(
		'plugin'                  => 'artivio-oxygen-agent',
		'pluginVersion'           => ARTIVIO_OXYGEN_AGENT_VERSION,
		'wp'                      => get_bloginfo( 'version' ),
		'php'                     => PHP_VERSION,
		'detectedOxygenVersion'   => $detected,
		'lastVerifiedAgainst'     => $verified,
		'versionDrift'            => ( null !== $detected && $detected !== $verified ),
		'note'                    => ( null !== $detected && $detected !== $verified )
			? 'Oxygen has updated since this plugin\'s assumptions (and the current playbook) were last verified. Oxygen 6.2 ships roughly weekly betas — re-run the standing test protocol before trusting old findings (which tool does what, whether design-property schemas are still empty on Container, etc.) against this version.'
			: 'Detected Oxygen version matches what this plugin was last verified against.',
	);
}

function artivio_oa_route_snapshot( WP_REST_Request $r ) {
	$post_id = (int) $r['id'];
	$guard   = artivio_oa_guard_post( $post_id );
	if ( is_wp_error( $guard ) ) {
		return $guard;
	}
	$label = (string) ( $r->get_param( 'label' ) ?: '' );
	$id    = artivio_oa_take_snapshot( $post_id, $label );
	return new WP_REST_Response(
		array(
			'post_id'     => $post_id,
			'snapshot_id' => $id,
			'label'       => $label,
			'note'        => 'Snapshot taken. Call /restore/' . $post_id . ' with this snapshot_id to undo any write made after this point.',
		),
		201
	);
}

function artivio_oa_route_list_snapshots( WP_REST_Request $r ) {
	$post_id = (int) $r['id'];
	$guard   = artivio_oa_guard_post( $post_id );
	if ( is_wp_error( $guard ) ) {
		return $guard;
	}
	$history = artivio_oa_get_history( $post_id );
	$summary = array();
	foreach ( $history as $snap ) {
		$summary[] = array(
			'id'             => $snap['id'],
			'timestamp'      => $snap['timestamp'],
			'label'          => $snap['label'],
			'oxygen_version' => $snap['oxygen_version'],
			'meta_key_count' => is_array( $snap['meta'] ) ? count( $snap['meta'] ) : 0,
		);
	}
	// Newest first — the one an agent almost always wants is the most recent.
	$summary = array_reverse( $summary );
	return array(
		'post_id'   => $post_id,
		'count'     => count( $summary ),
		'snapshots' => $summary,
		'max_kept'  => ARTIVIO_OXYGEN_AGENT_MAX_SNAPSHOTS,
	);
}

function artivio_oa_route_restore( WP_REST_Request $r ) {
	$post_id = (int) $r['id'];
	$guard   = artivio_oa_guard_post( $post_id );
	if ( is_wp_error( $guard ) ) {
		return $guard;
	}
	$snapshot_id = (string) $r->get_param( 'snapshot_id' );
	$result      = artivio_oa_restore_snapshot( $post_id, $snapshot_id );
	if ( is_wp_error( $result ) ) {
		return $result;
	}
	return new WP_REST_Response( $result, 200 );
}
