<?php
/**
 * Plugin Name:       Artivio Oxygen Audit
 * Description:       Read-only diagnostic endpoints for AI agents editing Oxygen Builder pages. Answers "did my class/style edit actually take effect on the live page?" without needing a browser.
 * Version:           1.4.0
 * Author:            Artivio
 * Requires PHP:      7.4
 *
 * ---------------------------------------------------------------------------
 * CHANGELOG
 * ---------------------------------------------------------------------------
 * 1.4.0 — Found during the real-complexity homepage build test
 *         (2026-09-09, build2.churchwebglobal.com, page 115, run by Noah):
 *         `audit-page` walks the FULL rendered page, which includes the
 *         site's global header/footer template — so a flag caused by
 *         site-wide markup (e.g. from post 50's header content) showed up
 *         attributed to an unrelated per-page audit (page 115), reading as
 *         a false positive if you assume every flag originated in the
 *         page you asked about. Fixed two ways:
 *   - Every flag in `audit-page`'s response now carries a `region` field:
 *     `header`, `footer`, `nav`, or `main_content` — detected by walking
 *     each element's ancestor chain for a `<header>`/`<footer>`/`<nav>`
 *     tag, or an id/class containing a common global-region marker
 *     (site-header, masthead, site-footer, colophon, global-header,
 *     global-footer — extend `artivio_oxygen_audit_global_region_markers()`
 *     if a theme uses different naming). This alone answers "did this
 *     flag come from the page I'm testing, or from the site-wide chrome"
 *     without changing existing behavior for anyone reading `flags` as
 *     before.
 *   - New opt-in param `?exclude_global_regions=1` filters `flags` down to
 *     `main_content` only — use this when auditing a specific page's own
 *     build work and global header/footer noise isn't relevant. Response
 *     now also reports `elements_flagged_main_content` and
 *     `elements_flagged_global_regions` as a breakdown regardless of
 *     whether the filter is applied, so the split is visible either way.
 *   - This is heuristic region detection, not a guarantee — a theme with
 *     no semantic `<header>`/`<footer>` tags and no matching id/class
 *     naming will have everything fall through to `main_content` (safe
 *     default: nothing gets hidden by an unrecognized theme).
 *
 * 1.3.0 — After the Test 1-6 investigation (build2.churchwebglobal.com)
 *         established that Oxygen 6.2's real per-element design-control
 *         path is `oxygen-set-element-variable-overrides` (a scoped CSS
 *         custom property), not `oxygen-edit-post`'s `design.*` (which is
 *         legitimately empty by architecture — see that investigation's
 *         notes). That tool returning `success: true` is not proof the
 *         override rendered — the exact "API succeeded, page didn't
 *         change" gap that caused the original BBI Argentina incidents.
 *         New endpoint closes it for variable overrides the same way
 *         `debug_class` closes it for classes:
 *
 *   GET /verify-variable-override/{post_id}?element_id=<int>&variable=<name>[&expected_value=<value>]
 *
 *   Checks, on the LIVE rendered page:
 *     - whether an element matching that element_id (an
 *       oxy-*-{post_id}-{element_id} class, matching how Oxygen names its
 *       auto-generated per-element classes) carries `--<variable>` either
 *       inline on its own `style` attribute, or via a scanned CSS rule
 *       whose selector targets that same element/class;
 *     - if `expected_value` is supplied, whether the found declaration's
 *       value matches it;
 *     - whether `var(--<variable>)` is referenced anywhere in scanned CSS
 *       at all (a set-but-never-consumed override is a real finding too —
 *       it means the intended child never picked up the change).
 *   Reports plainly which of "not found on the page at all" (the write
 *   didn't land), "found but wrong value", or "found, consumed, correct"
 *   actually happened — instead of trusting the write call's own verdict.
 *
 * 1.2.0 — Fixes from second real test (v1.1.0 on build2.churchwebglobal.com,
 *         page #9, run by Noah). The unused-classes noise fix worked
 *         (568 -> 87). The cache diagnostics ruled out staleness as the
 *         cause of the still-open Bug-1 miss (possible_stale_content:
 *         false, filter matched, fresh render) — so the miss is real and
 *         not explained by anything 1.1.0 added. Rather than guess again:
 *   - unused-classes now also filters out common WordPress/Gutenberg core
 *     utility classes (has-*-color, is-layout-*, wp-*, align*, etc.) —
 *     these are enqueued globally and will always show as "unused" on an
 *     Oxygen page; they were most of the remaining 87. Reported via
 *     `core_noise_filtered_count`; pass ?include_core_noise=1 to see them.
 *   - audit-page gains an opt-in debug lookup: pass ?debug_class=<name>
 *     and the response includes `debug_class_lookup` — whether that exact
 *     class string was found anywhere in the scanned CSS (and which rule,
 *     if so), AND which elements on the LIVE page currently carry that
 *     exact class in their class attribute, independent of whether the
 *     main scan flagged them. This is the direct way to answer "why isn't
 *     element 101 showing up" instead of reasoning about it blind — it
 *     will show either (a) no CSS rule for the string, and no element
 *     carries it either — meaning the edit never landed on the page the
 *     way the test assumes — or (b) an element does carry it but a CSS
 *     rule for that exact string exists too — meaning it's correctly not
 *     "unknown" and the test fixture needs a class with no rule at all —
 *     or (c) an element carries it, no CSS rule exists, and it's STILL
 *     not in `flags` — which would be the first actual evidence of a
 *     detection bug in the scan loop itself, at which point it gets fixed
 *     directly instead of guessed at.
 *
 * 1.1.0 — Fixes from first real test (build2.churchwebglobal.com, page #9,
 *         run by Noah):
 *   - unused-classes was reporting every class in every enqueued
 *     stylesheet (WordPress core, plugins, third-party JS libraries) —
 *     568 results on a 3-element test page, signal completely buried in
 *     noise. Fixed: CSS collection now scans inline <style> blocks plus
 *     only <link> stylesheets whose URL looks Oxygen-authored (falls
 *     back to scanning everything, clearly flagged, if none match — see
 *     $oxygen_hint_patterns below; adjust if your site's Oxygen CSS is
 *     served from a different path).
 *   - Both endpoints now report exactly which stylesheets were scanned
 *     (`stylesheets_scanned`), so it's never a silent guess.
 *   - Both endpoints now surface any cache-related response headers seen
 *     on the fetch (Age, X-Cache, CF-Cache-Status, Cache-Control) plus a
 *     `possible_stale_content` warning when one of those looks like a
 *     cache HIT. This directly targets the open question from the first
 *     test: whether a typo'd test class went undetected because the
 *     audited HTML was stale, not because the scanner skipped content
 *     elements (the xpath has never been scoped to body/links only —
 *     see NOTE below).
 *   - Hardened HTML parsing with explicit libxml flags
 *     (LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_NOBLANKS) — cheap
 *     insurance against malformed/deeply-nested builder markup silently
 *     truncating the parsed DOM, even though this wasn't confirmed as
 *     the actual cause this time.
 *
 * NOTE on the first test's Bug-1 failure: the report attributed it to
 * "the audit only scans <body> and skip-links, not Oxygen content
 * elements." That doesn't fully fit the evidence — the xpath used
 * (`//*[@class]`) is unscoped, and the SAME code path correctly found
 * `div.oxy-container-9-103` on the very next call. A structural
 * "can't reach Oxygen divs" bug wouldn't explain finding one Oxygen div
 * and not another with identical logic. The more consistent explanation
 * is that the two calls fetched two different snapshots of the page
 * (stale vs fresh) — hence the cache diagnostics added in this version,
 * rather than a content-scanning fix that the evidence doesn't actually
 * point to. Re-test with 1.1.0 and check `cache_headers_seen` /
 * `possible_stale_content` in the response before assuming either
 * explanation — this version is built to tell you which one it was.
 *
 * ---------------------------------------------------------------------------
 * WHAT THIS PLUGIN IS FOR
 * ---------------------------------------------------------------------------
 * Oxygen Builder elements carry classes, and those classes only mean
 * something if a matching CSS rule exists AND is actually attached to the
 * element. Nothing in the normal Oxygen MCP toolset verifies that pairing
 * after an edit. This plugin exposes two REST endpoints that do real,
 * callable, structural analysis of a LIVE rendered page (not the builder's
 * internal JSON), so an agent can self-check before declaring a fix done:
 *
 *   GET /wp-json/artivio-oxygen-audit/v1/audit-page/{post_id}
 *   GET /wp-json/artivio-oxygen-audit/v1/unused-classes/{post_id}
 *   GET /wp-json/artivio-oxygen-audit/v1/status
 *
 * ---------------------------------------------------------------------------
 * HONEST LIMITATIONS (read before trusting this blindly)
 * ---------------------------------------------------------------------------
 * This is deliberately a lightweight static-analysis tool, NOT a headless
 * browser and NOT a real CSS cascade engine. It does NOT:
 *   - Resolve specificity, !important, or rule ORDER precisely.
 *   - Evaluate @media queries conditionally (a mobile-only rule still
 *     counts as "this class has a background-color rule").
 *   - Resolve inherited values from ancestor elements — a text element
 *     with its color set directly (not inherited) will NOT be flagged as
 *     invisible against its parent's background; this tool only checks
 *     whether an element's OWN classes declare a property, not whether
 *     the resulting color is legible against whatever is behind it.
 *   - Understand selectors more complex than ".class" or ".class tag".
 *   - See anything a caching layer decided not to serve fresh. This tool
 *     fetches the page the same way any HTTP client would — if the site
 *     has a page cache/CDN in front of it, a just-made edit may not be
 *     visible yet. Check `possible_stale_content` in the response.
 *
 * Treat a flag from this tool as "look here first", not as ground truth.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'ARTIVIO_OXYGEN_AUDIT_VERSION', '1.4.0' );
define( 'ARTIVIO_OXYGEN_AUDIT_NS', 'artivio-oxygen-audit/v1' );

/**
 * Class-name prefixes that are WordPress/Gutenberg core utility classes,
 * not anything Oxygen or a site builder wrote on purpose. These get
 * enqueued globally (block library CSS, theme.json presets) and will
 * always show up as "unused" on any single Oxygen page — they're noise,
 * not leftover build debris. Filtered out of unused-classes by default;
 * pass ?include_core_noise=1 to see them anyway.
 */
function artivio_oxygen_audit_core_noise_patterns() {
	return array( 'has-', 'is-layout-', 'is-content-justification-', 'is-nowrap', 'wp-', 'align', 'screen-reader-text' );
}

function artivio_oxygen_audit_is_core_noise( $cls ) {
	foreach ( artivio_oxygen_audit_core_noise_patterns() as $pattern ) {
		if ( 0 === strpos( $cls, $pattern ) ) {
			return true;
		}
	}
	return false;
}

/**
 * id/class substrings that mark a global template region (site-wide
 * header/footer/nav chrome, not this specific page's own content). Added
 * in 1.4.0 after a real false-positive was found: a flag caused by
 * site-wide header markup showed up attributed to an unrelated page's
 * audit. Extend this list if a theme uses different naming than these
 * common WordPress conventions.
 */
function artivio_oxygen_audit_global_region_markers() {
	return array(
		'header' => array( 'site-header', 'masthead', 'global-header' ),
		'footer' => array( 'site-footer', 'colophon', 'global-footer' ),
	);
}

/**
 * Walks an element's ancestor chain to classify which part of the page it
 * lives in: 'header', 'footer', 'nav', or 'main_content' (the safe
 * default when nothing matches — an unrecognized theme never gets
 * anything hidden, it just falls through to main_content).
 */
function artivio_oxygen_audit_detect_region( $el ) {
	$markers = artivio_oxygen_audit_global_region_markers();
	$node    = $el;

	while ( $node instanceof DOMElement ) {
		$tag = strtolower( $node->tagName );
		if ( in_array( $tag, array( 'header', 'footer', 'nav' ), true ) ) {
			return $tag;
		}

		$haystack = strtolower( (string) $node->getAttribute( 'id' ) ) . ' ' . strtolower( (string) $node->getAttribute( 'class' ) );
		foreach ( $markers['header'] as $needle ) {
			if ( false !== strpos( $haystack, $needle ) ) {
				return 'header';
			}
		}
		foreach ( $markers['footer'] as $needle ) {
			if ( false !== strpos( $haystack, $needle ) ) {
				return 'footer';
			}
		}

		$node = $node->parentNode;
	}

	return 'main_content';
}

/**
 * Substrings used to recognize an Oxygen-authored stylesheet URL. Adjust
 * this list if a site serves its Oxygen CSS from a different path pattern
 * — the plugin will tell you (via `stylesheets_scanned` /
 * `oxygen_stylesheet_filter_matched`) whether any stylesheet matched, so
 * it's obvious when this list needs updating for a given host.
 */
function artivio_oxygen_audit_hint_patterns() {
	return array( 'oxygen', 'ct-builder', 'oxy-' );
}

add_action( 'rest_api_init', 'artivio_oxygen_audit_register_routes' );

function artivio_oxygen_audit_register_routes() {
	register_rest_route(
		ARTIVIO_OXYGEN_AUDIT_NS,
		'/status',
		array(
			'methods'             => 'GET',
			'callback'            => 'artivio_oxygen_audit_status',
			'permission_callback' => 'artivio_oxygen_audit_permission_check',
		)
	);

	register_rest_route(
		ARTIVIO_OXYGEN_AUDIT_NS,
		'/audit-page/(?P<id>\d+)',
		array(
			'methods'             => 'GET',
			'callback'            => 'artivio_oxygen_audit_page',
			'permission_callback' => 'artivio_oxygen_audit_permission_check',
			'args'                => array(
				'id' => array(
					'validate_callback' => function ( $param ) {
						return is_numeric( $param );
					},
				),
				'debug_class' => array(
					'required' => false,
				),
				'exclude_global_regions' => array(
					'required' => false,
				),
			),
		)
	);

	register_rest_route(
		ARTIVIO_OXYGEN_AUDIT_NS,
		'/unused-classes/(?P<id>\d+)',
		array(
			'methods'             => 'GET',
			'callback'            => 'artivio_oxygen_audit_unused_classes',
			'permission_callback' => 'artivio_oxygen_audit_permission_check',
			'args'                => array(
				'id' => array(
					'validate_callback' => function ( $param ) {
						return is_numeric( $param );
					},
				),
				'include_core_noise' => array(
					'required' => false,
				),
			),
		)
	);

	register_rest_route(
		ARTIVIO_OXYGEN_AUDIT_NS,
		'/verify-variable-override/(?P<id>\d+)',
		array(
			'methods'             => 'GET',
			'callback'            => 'artivio_oxygen_audit_verify_variable_override',
			'permission_callback' => 'artivio_oxygen_audit_permission_check',
			'args'                => array(
				'id' => array(
					'validate_callback' => function ( $param ) {
						return is_numeric( $param );
					},
				),
				'element_id' => array(
					'required'          => true,
					'validate_callback' => function ( $param ) {
						return is_numeric( $param );
					},
				),
				'variable' => array(
					'required' => true,
				),
				'expected_value' => array(
					'required' => false,
				),
			),
		)
	);
}

function artivio_oxygen_audit_permission_check() {
	return current_user_can( 'edit_posts' );
}

function artivio_oxygen_audit_status( WP_REST_Request $request ) {
	return new WP_REST_Response(
		array(
			'plugin_version' => ARTIVIO_OXYGEN_AUDIT_VERSION,
			'wp_version'     => get_bloginfo( 'version' ),
			'active_theme'   => wp_get_theme()->get( 'Name' ),
			'site_url'       => site_url(),
		),
		200
	);
}

/**
 * Headers worth surfacing to help an agent tell "this might be a stale
 * cached copy" from "this is genuinely what's live right now."
 */
function artivio_oxygen_audit_cache_headers( $response ) {
	$watched = array( 'age', 'x-cache', 'cf-cache-status', 'cache-control', 'x-litespeed-cache', 'x-nginx-cache' );
	$seen    = array();
	foreach ( $watched as $header ) {
		$value = wp_remote_retrieve_header( $response, $header );
		if ( ! empty( $value ) ) {
			$seen[ $header ] = $value;
		}
	}
	return $seen;
}

function artivio_oxygen_audit_looks_stale( $cache_headers ) {
	foreach ( $cache_headers as $header => $value ) {
		$value_lc = strtolower( is_array( $value ) ? implode( ',', $value ) : $value );
		if ( 'age' === $header && is_numeric( $value ) && (int) $value > 5 ) {
			return true; // Served from cache more than 5s old.
		}
		if ( false !== strpos( $value_lc, 'hit' ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Fetch a post's live rendered HTML via an internal loopback request.
 * Returns [ $html, $cache_headers, $error ].
 */
function artivio_oxygen_audit_fetch_page( $post_id ) {
	$post = get_post( $post_id );
	if ( ! $post ) {
		return array( null, array(), 'post_not_found' );
	}

	$url = get_permalink( $post_id );
	if ( ! $url ) {
		return array( null, array(), 'no_permalink' );
	}

	$url = add_query_arg( 'artivio_audit_nocache', time() . '-' . wp_rand( 1000, 9999 ), $url );

	$response = wp_remote_get(
		$url,
		array(
			'timeout'   => 20,
			'sslverify' => false,
			'headers'   => array(
				'Cache-Control' => 'no-cache, no-store, must-revalidate',
				'Pragma'        => 'no-cache',
			),
		)
	);

	if ( is_wp_error( $response ) ) {
		return array( null, array(), 'fetch_failed: ' . $response->get_error_message() );
	}

	$html = wp_remote_retrieve_body( $response );
	if ( empty( $html ) ) {
		return array( null, array(), 'empty_response' );
	}

	$cache_headers = artivio_oxygen_audit_cache_headers( $response );

	return array( $html, $cache_headers, null );
}

/**
 * Pull stylesheet text out of a page: inline <style> blocks always, plus
 * external <link rel="stylesheet"> only when the URL matches one of the
 * Oxygen hint patterns — this is what keeps unused-classes from drowning
 * in WordPress-core/plugin/vendor CSS. If NOTHING matches the hint
 * patterns, falls back to scanning everything so the tool never silently
 * returns nothing; `oxygen_stylesheet_filter_matched` tells you which
 * happened.
 *
 * Returns [ $css_text, $stylesheets_scanned, $filter_matched ]
 */
function artivio_oxygen_audit_collect_css( $html, $base_url ) {
	libxml_use_internal_errors( true );
	$dom = new DOMDocument();
	$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html, LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_NOBLANKS );
	libxml_clear_errors();

	$inline_chunks    = array();
	foreach ( $dom->getElementsByTagName( 'style' ) as $style_node ) {
		$inline_chunks[] = $style_node->textContent;
	}

	$hint_patterns    = artivio_oxygen_audit_hint_patterns();
	$candidate_links  = array(); // href => matched-hint (bool)
	foreach ( $dom->getElementsByTagName( 'link' ) as $link_node ) {
		$rel = strtolower( (string) $link_node->getAttribute( 'rel' ) );
		if ( 'stylesheet' !== $rel ) {
			continue;
		}
		$href = $link_node->getAttribute( 'href' );
		if ( empty( $href ) ) {
			continue;
		}
		if ( 0 === strpos( $href, '//' ) ) {
			$href = 'https:' . $href;
		} elseif ( 0 === strpos( $href, '/' ) ) {
			$parsed = wp_parse_url( $base_url );
			$href   = $parsed['scheme'] . '://' . $parsed['host'] . $href;
		}

		$matched = false;
		foreach ( $hint_patterns as $pattern ) {
			if ( false !== stripos( $href, $pattern ) ) {
				$matched = true;
				break;
			}
		}
		$candidate_links[ $href ] = $matched;
	}

	$matched_links = array_keys( array_filter( $candidate_links ) );
	$filter_matched = ! empty( $matched_links );
	$links_to_fetch = $filter_matched ? $matched_links : array_keys( $candidate_links );

	$css_chunks     = $inline_chunks;
	$stylesheets_scanned = array();
	if ( ! empty( $inline_chunks ) ) {
		$stylesheets_scanned[] = 'inline <style> blocks (' . count( $inline_chunks ) . ')';
	}

	foreach ( $links_to_fetch as $href ) {
		$css_response = wp_remote_get( $href, array( 'timeout' => 15, 'sslverify' => false ) );
		if ( ! is_wp_error( $css_response ) ) {
			$css_chunks[]           = wp_remote_retrieve_body( $css_response );
			$stylesheets_scanned[]  = $href;
		}
	}

	return array( implode( "\n", $css_chunks ), $stylesheets_scanned, $filter_matched );
}

function artivio_oxygen_audit_parse_css( $css_text ) {
	$class_props      = array();
	$all_class_tokens = array();

	$css_text = preg_replace( '!/\*.*?\*/!s', '', $css_text );

	if ( ! preg_match_all( '/([^{}]+)\{([^{}]*)\}/s', $css_text, $matches, PREG_SET_ORDER ) ) {
		return array( $class_props, $all_class_tokens );
	}

	foreach ( $matches as $match ) {
		$selector_list = trim( $match[1] );
		$declarations  = trim( $match[2] );

		if ( '' === $selector_list || '' === $declarations || 0 === strpos( $selector_list, '@' ) ) {
			continue;
		}

		if ( preg_match_all( '/\.([a-zA-Z0-9_-]+)/', $selector_list, $class_hits ) ) {
			foreach ( $class_hits[1] as $cls ) {
				$all_class_tokens[ $cls ] = true;
			}
		}

		$props = array();
		foreach ( explode( ';', $declarations ) as $decl ) {
			$decl = trim( $decl );
			if ( '' === $decl || false === strpos( $decl, ':' ) ) {
				continue;
			}
			list( $prop ) = explode( ':', $decl, 2 );
			$props[]      = strtolower( trim( $prop ) );
		}
		if ( empty( $props ) ) {
			continue;
		}

		foreach ( explode( ',', $selector_list ) as $selector ) {
			$selector = trim( $selector );

			if ( preg_match( '/^\.([a-zA-Z0-9_-]+)$/', $selector, $m ) ) {
				$cls = $m[1];
				foreach ( $props as $prop ) {
					$class_props[ $cls ][ $prop ][] = trim( $selector_list ) . ' { ' . trim( $declarations ) . ' }';
				}
				continue;
			}

			if ( preg_match( '/^\.([a-zA-Z0-9_-]+)\s+([a-zA-Z][a-zA-Z0-9]*)$/', $selector, $m ) ) {
				$cls    = $m[1];
				$bucket = 'descendant_' . strtolower( $m[2] );
				foreach ( $props as $prop ) {
					$class_props[ $cls ][ $bucket . ':' . $prop ][] = trim( $selector_list ) . ' { ' . trim( $declarations ) . ' }';
				}
				continue;
			}
		}
	}

	return array( $class_props, $all_class_tokens );
}

function artivio_oxygen_audit_watched_properties() {
	return array( 'background-color', 'background', 'padding', 'color' );
}

function artivio_oxygen_audit_page( WP_REST_Request $request ) {
	$post_id = (int) $request['id'];

	list( $html, $cache_headers, $error ) = artivio_oxygen_audit_fetch_page( $post_id );
	if ( $error ) {
		return new WP_REST_Response( array( 'error' => $error ), 400 );
	}

	list( $css_text, $stylesheets_scanned, $filter_matched ) = artivio_oxygen_audit_collect_css( $html, get_permalink( $post_id ) );
	list( $class_props, $all_class_tokens )                  = artivio_oxygen_audit_parse_css( $css_text );
	$watched = artivio_oxygen_audit_watched_properties();

	libxml_use_internal_errors( true );
	$dom = new DOMDocument();
	$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html, LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_NOBLANKS );
	libxml_clear_errors();

	$xpath    = new DOMXPath( $dom );
	$elements = $xpath->query( '//*[@class]' );

	$results       = array();
	$flagged_count = 0;
	$scanned_count = 0;

	foreach ( $elements as $el ) {
		$class_attr = trim( $el->getAttribute( 'class' ) );
		if ( '' === $class_attr ) {
			continue;
		}
		$scanned_count++;
		$classes = preg_split( '/\s+/', $class_attr );

		$checkable_classes = array_filter(
			$classes,
			function ( $c ) {
				return ! preg_match( '/^oxy-(container|text|text-link)-\d+-\d+$/', $c )
					&& 'oxy-container' !== $c && 'oxy-text' !== $c && 'oxy-text-link' !== $c;
			}
		);

		if ( empty( $checkable_classes ) ) {
			continue;
		}

		$unknown_classes = array();
		$has_property     = array();
		foreach ( $watched as $prop ) {
			$has_property[ $prop ] = false;
		}

		foreach ( $checkable_classes as $cls ) {
			if ( ! isset( $all_class_tokens[ $cls ] ) ) {
				$unknown_classes[] = $cls;
				continue;
			}
			if ( isset( $class_props[ $cls ] ) ) {
				foreach ( $watched as $prop ) {
					if ( isset( $class_props[ $cls ][ $prop ] ) ) {
						$has_property[ $prop ] = true;
					}
				}
			}
		}

		$missing = array_keys( array_filter( $has_property, function ( $v ) {
			return ! $v;
		} ) );

		$tag_lc         = strtolower( $el->tagName );
		$is_container   = in_array( $tag_lc, array( 'section', 'div' ), true );
		$is_text_bearer = in_array( $tag_lc, array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'span', 'a', 'li' ), true );
		$has_text       = '' !== trim( $el->textContent );

		$noteworthy = ! empty( $unknown_classes )
			|| ( $is_container && ! $has_property['background-color'] && ! $has_property['background'] )
			|| ( $is_text_bearer && $has_text && ! $has_property['color'] );

		if ( ! $noteworthy ) {
			continue;
		}

		$flagged_count++;
		$results[] = array(
			'tag'                       => $tag_lc,
			'classes'                   => array_values( $classes ),
			'text_preview'              => mb_substr( trim( preg_replace( '/\s+/', ' ', $el->textContent ) ), 0, 60 ),
			'unknown_classes'           => array_values( $unknown_classes ),
			'missing_from_own_classes'  => array_values( $missing ),
			'region'                    => artivio_oxygen_audit_detect_region( $el ),
			'note'                      => 'Flagged heuristically — check ancestors before assuming this is broken (see plugin limitations).',
		);
	}

	$main_content_flags = array_values( array_filter( $results, function ( $r ) {
		return 'main_content' === $r['region'];
	} ) );
	$global_region_flags = array_values( array_filter( $results, function ( $r ) {
		return 'main_content' !== $r['region'];
	} ) );

	$exclude_global_regions = ! empty( $request->get_param( 'exclude_global_regions' ) );

	$response_data = array(
		'post_id'                          => $post_id,
		'audited_url'                       => get_permalink( $post_id ),
		'elements_with_class_scanned'       => $scanned_count,
		'elements_flagged'                  => $flagged_count,
		'elements_flagged_main_content'     => count( $main_content_flags ),
		'elements_flagged_global_regions'   => count( $global_region_flags ),
		'exclude_global_regions_applied'    => $exclude_global_regions,
		'flags'                             => $exclude_global_regions ? $main_content_flags : $results,
		'stylesheets_scanned'                => $stylesheets_scanned,
		'oxygen_stylesheet_filter_matched'   => $filter_matched,
		'cache_headers_seen'                 => $cache_headers,
		'possible_stale_content'             => artivio_oxygen_audit_looks_stale( $cache_headers ),
		'limitations'                        => 'Heuristic static analysis: no cascade/specificity resolution, no media-query awareness, no ancestor inheritance. Region detection (header/footer/nav vs. main_content) is also heuristic — see plugin header docblock.',
	);

	$debug_class = $request->get_param( 'debug_class' );
	if ( ! empty( $debug_class ) ) {
		// Class names only ever contain these characters in practice; strip
		// anything else so the value is safe to interpolate into an XPath
		// string literal below.
		$debug_class = preg_replace( '/[^a-zA-Z0-9_-]/', '', $debug_class );
	}
	if ( ! empty( $debug_class ) ) {
		$response_data['debug_class_lookup'] = artivio_oxygen_audit_debug_class_lookup(
			$debug_class,
			$dom,
			$all_class_tokens,
			isset( $class_props[ $debug_class ] ) ? $class_props[ $debug_class ] : array()
		);
	}

	return new WP_REST_Response( $response_data, 200 );
}

/**
 * Answers "why isn't this exact class name showing up as flagged/unknown?"
 * directly, instead of leaving it to be reasoned about from the outside.
 * Reports (a) whether the literal string was found in any scanned CSS
 * selector, with matching rule snippets if so, and (b) every element on
 * the LIVE page whose class attribute currently contains this literal
 * token, regardless of whether the main scan loop flagged it.
 */
function artivio_oxygen_audit_debug_class_lookup( $cls, $dom, $all_class_tokens, $matched_props ) {
	$in_css = isset( $all_class_tokens[ $cls ] );

	$rule_snippets = array();
	foreach ( $matched_props as $prop => $rules ) {
		foreach ( $rules as $rule ) {
			$rule_snippets[] = $rule;
		}
	}
	$rule_snippets = array_slice( array_unique( $rule_snippets ), 0, 5 );

	$xpath    = new DOMXPath( $dom );
	$carriers = $xpath->query(
		"//*[contains(concat(' ', normalize-space(@class), ' '), ' " . $cls . " ')]"
	);

	$elements_with_class = array();
	foreach ( $carriers as $el ) {
		$elements_with_class[] = array(
			'tag'          => strtolower( $el->tagName ),
			'classes'      => preg_split( '/\s+/', trim( $el->getAttribute( 'class' ) ) ),
			'text_preview' => mb_substr( trim( preg_replace( '/\s+/', ' ', $el->textContent ) ), 0, 60 ),
		);
	}

	return array(
		'class_name'                => $cls,
		'found_in_scanned_css'      => $in_css,
		'matching_css_rule_snippets' => $rule_snippets,
		'elements_carrying_this_class_on_live_page' => $elements_with_class,
		'interpretation' => empty( $elements_with_class )
			? 'No element on the LIVE page currently carries this exact class string. If a test expected this class to be present, the edit did not land on the page this endpoint fetched — check possible_stale_content, or re-verify the edit was saved.'
			: ( $in_css
				? 'At least one element carries this class, AND a CSS rule exists for this exact string — so it is correctly not flagged as "unknown" (a rule does match it). If this was meant to be an undefined/typo class for testing, the test fixture needs a class string with no matching rule anywhere in scanned CSS.'
				: 'At least one element carries this class and NO CSS rule matches it anywhere in scanned CSS, yet it did not appear in `flags` — this is a genuine detection-loop bug, not a false theory. Report this exact debug_class_lookup output back for a real fix.' ),
	);
}

function artivio_oxygen_audit_unused_classes( WP_REST_Request $request ) {
	$post_id = (int) $request['id'];

	list( $html, $cache_headers, $error ) = artivio_oxygen_audit_fetch_page( $post_id );
	if ( $error ) {
		return new WP_REST_Response( array( 'error' => $error ), 400 );
	}

	list( $css_text, $stylesheets_scanned, $filter_matched ) = artivio_oxygen_audit_collect_css( $html, get_permalink( $post_id ) );
	list( $class_props, $all_class_tokens )                  = artivio_oxygen_audit_parse_css( $css_text );

	libxml_use_internal_errors( true );
	$dom = new DOMDocument();
	$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html, LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_NOBLANKS );
	libxml_clear_errors();

	$xpath        = new DOMXPath( $dom );
	$elements     = $xpath->query( '//*[@class]' );
	$used_classes = array();

	foreach ( $elements as $el ) {
		$class_attr = trim( $el->getAttribute( 'class' ) );
		if ( '' === $class_attr ) {
			continue;
		}
		foreach ( preg_split( '/\s+/', $class_attr ) as $cls ) {
			$used_classes[ $cls ] = true;
		}
	}

	$include_core_noise   = ! empty( $request->get_param( 'include_core_noise' ) );
	$core_noise_filtered  = 0;

	$unused = array();
	foreach ( $all_class_tokens as $cls => $_true ) {
		if ( isset( $used_classes[ $cls ] ) ) {
			continue;
		}
		if ( ! $include_core_noise && artivio_oxygen_audit_is_core_noise( $cls ) ) {
			$core_noise_filtered++;
			continue;
		}
		$snippets = array();
		if ( isset( $class_props[ $cls ] ) ) {
			foreach ( $class_props[ $cls ] as $prop => $rules ) {
				$snippets[] = $rules[0];
			}
		}
		$unused[] = array(
			'class'   => $cls,
			'rules'   => array_slice( array_unique( $snippets ), 0, 5 ),
			'meaning' => 'This class has a CSS rule (in a scanned Oxygen stylesheet) but is not applied to any element currently on this page — likely leftover from an earlier build attempt. Consider reusing it by name before writing a new class.',
		);
	}

	usort(
		$unused,
		function ( $a, $b ) {
			return count( $b['rules'] ) <=> count( $a['rules'] );
		}
	);

	return new WP_REST_Response(
		array(
			'post_id'                          => $post_id,
			'audited_url'                       => get_permalink( $post_id ),
			'unused_class_count'                 => count( $unused ),
			'unused_classes'                     => $unused,
			'core_noise_filtered_count'           => $core_noise_filtered,
			'core_noise_filter_applied'           => ! $include_core_noise,
			'stylesheets_scanned'                 => $stylesheets_scanned,
			'oxygen_stylesheet_filter_matched'    => $filter_matched,
			'cache_headers_seen'                  => $cache_headers,
			'possible_stale_content'              => artivio_oxygen_audit_looks_stale( $cache_headers ),
		),
		200
	);
}

/**
 * Finds every inline `--name: value;` custom-property declaration on an
 * element's own `style` attribute.
 */
function artivio_oxygen_audit_inline_var_declarations( $style_attr, $var_name ) {
	$found = array();
	if ( '' === trim( (string) $style_attr ) ) {
		return $found;
	}
	// Match "--var-name : value" up to the next ';' or end of string.
	$pattern = '/--' . preg_quote( $var_name, '/' ) . '\s*:\s*([^;]+);?/i';
	if ( preg_match_all( $pattern, $style_attr, $m ) ) {
		foreach ( $m[1] as $value ) {
			$found[] = trim( $value );
		}
	}
	return $found;
}

/**
 * Finds `--name: value;` inside scanned CSS rules whose selector mentions
 * the given class (covers the case where Oxygen renders a scoped override
 * as a generated stylesheet rule rather than an inline style attribute).
 */
function artivio_oxygen_audit_css_var_declarations( $css_text, $class_hint, $var_name ) {
	$found = array();
	if ( '' === trim( (string) $css_text ) ) {
		return $found;
	}
	if ( ! preg_match_all( '/([^{}]+)\{([^{}]*)\}/s', $css_text, $blocks, PREG_SET_ORDER ) ) {
		return $found;
	}
	foreach ( $blocks as $block ) {
		$selector = $block[1];
		$decls    = $block[2];
		if ( false === stripos( $selector, $class_hint ) ) {
			continue;
		}
		$pattern = '/--' . preg_quote( $var_name, '/' ) . '\s*:\s*([^;]+);?/i';
		if ( preg_match_all( $pattern, $decls, $m ) ) {
			foreach ( $m[1] as $value ) {
				$found[] = trim( $value ) . '  (selector: ' . trim( $selector ) . ')';
			}
		}
	}
	return $found;
}

/**
 * GET /verify-variable-override/{post_id}?element_id=<int>&variable=<name>[&expected_value=<value>]
 *
 * See 1.3.0 changelog note above for why this exists: a `success: true`
 * from `oxygen-set-element-variable-overrides` is not proof the override
 * actually reached the rendered page.
 */
function artivio_oxygen_audit_verify_variable_override( WP_REST_Request $request ) {
	$post_id    = (int) $request['id'];
	$element_id = (int) $request->get_param( 'element_id' );
	$var_name   = ltrim( (string) $request->get_param( 'variable' ), '-' );
	$var_name   = preg_replace( '/[^a-zA-Z0-9_-]/', '', $var_name );
	$expected   = $request->get_param( 'expected_value' );

	list( $html, $cache_headers, $error ) = artivio_oxygen_audit_fetch_page( $post_id );
	if ( $error ) {
		return new WP_REST_Response( array( 'error' => $error ), 400 );
	}
	list( $css_text, $stylesheets_scanned, $filter_matched ) = artivio_oxygen_audit_collect_css( $html, get_permalink( $post_id ) );

	libxml_use_internal_errors( true );
	$dom = new DOMDocument();
	$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html, LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_NOBLANKS );
	libxml_clear_errors();

	// Oxygen's own auto-generated per-element classes take the shape
	// oxy-{type}-{post_id}-{element_id} — this is how earlier incidents
	// (BBI Argentina, this plugin's own debug_class lookup) identified a
	// specific element without needing its DOM id/path.
	$class_hint = '-' . $post_id . '-' . $element_id;

	$xpath    = new DOMXPath( $dom );
	$carriers = $xpath->query( "//*[contains(@class, '" . $class_hint . "')]" );

	$inline_declarations = array();
	$matched_elements     = array();
	foreach ( $carriers as $el ) {
		$style = $el->getAttribute( 'style' );
		$decls = artivio_oxygen_audit_inline_var_declarations( $style, $var_name );
		$matched_elements[] = array(
			'tag'     => strtolower( $el->tagName ),
			'classes' => preg_split( '/\s+/', trim( $el->getAttribute( 'class' ) ) ),
			'style'   => $style,
		);
		foreach ( $decls as $d ) {
			$inline_declarations[] = $d;
		}
	}

	$css_declarations = artivio_oxygen_audit_css_var_declarations( $css_text, $class_hint, $var_name );
	$referenced_anywhere = ( false !== stripos( $css_text, 'var(--' . $var_name ) );

	$all_values_found = array_merge( $inline_declarations, $css_declarations );
	$found             = ! empty( $all_values_found );
	$value_matches     = null;
	if ( $found && null !== $expected && '' !== (string) $expected ) {
		$value_matches = false;
		foreach ( $all_values_found as $v ) {
			// css_declarations entries have a trailing "(selector: ...)" note; compare loosely.
			if ( false !== stripos( $v, (string) $expected ) ) {
				$value_matches = true;
				break;
			}
		}
	}

	if ( empty( $matched_elements ) ) {
		$interpretation = 'No element on the LIVE page matches element_id ' . $element_id . ' for post ' . $post_id . ' (looked for class containing "' . $class_hint . '"). Either the element id is wrong, or the page fetched is stale — check possible_stale_content.';
	} elseif ( ! $found ) {
		$interpretation = 'The target element was found on the page, but no "--' . $var_name . '" declaration exists on it (inline or in scanned CSS). The write likely did not actually reach the rendered page — re-check the write call, and consider this Bug 7 rather than assuming success.';
	} elseif ( false === $value_matches ) {
		$interpretation = 'The variable IS set on the element, but its value does not match expected_value. Check for a competing declaration overriding it, or that the write sent the intended value.';
	} else {
		$interpretation = 'The variable is set on the element' . ( null !== $value_matches ? ' with the expected value' : '' ) . '.' . ( $referenced_anywhere ? ' It is also referenced via var(--' . $var_name . ') elsewhere in scanned CSS, so a visible effect is plausible.' : ' WARNING: nothing in scanned CSS actually references var(--' . $var_name . ') — the override may be set but have no visible effect because nothing consumes it.' );
	}

	return new WP_REST_Response(
		array(
			'post_id'                 => $post_id,
			'element_id'              => $element_id,
			'variable'                => $var_name,
			'matched_elements'        => $matched_elements,
			'inline_declarations'     => $inline_declarations,
			'css_rule_declarations'   => $css_declarations,
			'found'                   => $found,
			'expected_value'          => $expected,
			'value_matches_expected'  => $value_matches,
			'referenced_via_var_anywhere' => $referenced_anywhere,
			'stylesheets_scanned'     => $stylesheets_scanned,
			'oxygen_stylesheet_filter_matched' => $filter_matched,
			'cache_headers_seen'      => $cache_headers,
			'possible_stale_content'  => artivio_oxygen_audit_looks_stale( $cache_headers ),
			'interpretation'          => $interpretation,
		),
		200
	);
}
