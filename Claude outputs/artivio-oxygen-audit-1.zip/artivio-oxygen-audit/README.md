# Artivio Oxygen Audit

A small, read-only WordPress plugin that gives an AI agent a way to check
"did my Oxygen class/style edit actually take effect on the live page?"
without needing a browser. Built directly from three incidents where Theo
reported a fix as done while a class was silently detached from its CSS
rule, then hardened after a real-world test on build2.churchwebglobal.com
(Noah) surfaced two more issues — see Changelog below.

## Install

1. Upload the `artivio-oxygen-audit` folder to `wp-content/plugins/` on
   the target site (or zip it and use **Plugins → Add New → Upload
   Plugin** in wp-admin).
2. Activate it from **Plugins**.
3. No settings page — it just exposes three REST endpoints, authenticated
   the same way as any other WP REST call (Application Passwords over
   Basic Auth, or a logged-in session).

## Endpoints

- `GET /wp-json/artivio-oxygen-audit/v1/status`
  Health check — plugin version, WP version, active theme.

- `GET /wp-json/artivio-oxygen-audit/v1/audit-page/{post_id}`
  Fetches the LIVE rendered page and flags elements where:
  - one of its classes doesn't exist in any loaded stylesheet at all
    (a typo'd or never-written class), or
  - it's a section/div-like container with none of its own classes
    declaring a background, or
  - it visibly contains text but none of its own classes declare a
    text color (the "white text on white background" bug).

  Also returns, for transparency and debugging:
  - `elements_with_class_scanned` — total elements-with-a-class the
    xpath walk encountered on this fetch.
  - `stylesheets_scanned` / `oxygen_stylesheet_filter_matched` — see
    "Stylesheet filtering" below.
  - `cache_headers_seen` / `possible_stale_content` — see "Cache
    diagnostics" below.

- `GET /wp-json/artivio-oxygen-audit/v1/unused-classes/{post_id}`
  Lists every class-based CSS rule on the page's stylesheets that
  currently matches **zero** elements on the page — i.e. CSS left over
  from an earlier build attempt, sitting there unused and reusable by
  name instead of writing something new from scratch. Same
  `stylesheets_scanned` / `oxygen_stylesheet_filter_matched` /
  `cache_headers_seen` / `possible_stale_content` fields are included.

## Stylesheet filtering (new in 1.1.0)

v1.0.0 collected CSS from **every** stylesheet enqueued on the page —
WP core, plugins like The Events Calendar, tooltipster, etc. — not just
the Oxygen-authored CSS. On a real site with a normal plugin stack this
buried the signal: a test on build2.churchwebglobal.com returned 568
"unused classes," almost all of them noise from unrelated plugin CSS.

v1.1.0 filters `<link rel=stylesheet>` tags to only the ones whose URL
looks Oxygen-related (contains `oxygen`, `ct-builder`, or `oxy-`).
Inline `<style>` blocks are still always scanned, since Oxygen writes a
lot of its per-post CSS inline. If nothing on the page matches the
Oxygen hint patterns, the filter automatically falls back to scanning
everything (better to be noisy than silent) and reports
`oxygen_stylesheet_filter_matched: false` so you know the fallback fired.

`stylesheets_scanned` always lists exactly which stylesheet URLs were
actually parsed, so a report can be checked against what was on the page.

## Cache diagnostics (new in 1.1.0)

A build2.churchwebglobal.com test also reported `audit-page` failing to
flag a typo'd class before a fix, and then (expectedly, correctly) not
flagging it after the fix. The stated root cause in that report —
"audit-page only scans `<body>`/`<a>`, never reaches Oxygen content
elements" — doesn't fit the rest of that same report: the identical
unscoped xpath (`//*[@class]`) *did* find `div.oxy-container-9-103` in
the very next (after-fix) call. A scanner that structurally can't reach
Oxygen divs shouldn't suddenly reach one two calls later with no code
change in between.

Rather than guess at a fix for a cause that doesn't match the evidence,
1.1.0 adds instrumentation so the next test can tell us which
explanation is right:
- `cache_headers_seen` — whatever `Age`, `X-Cache`, `CF-Cache-Status`,
  `Cache-Control`, `X-Litespeed-Cache`, `X-Nginx-Cache` headers came
  back on the server-side loopback fetch of the page.
- `possible_stale_content` — `true` if `Age > 5` or any of the above
  headers contains "hit" (case-insensitive) — a heuristic flag that a
  caching layer served an older snapshot of the page rather than the
  one that was just saved.

If a "before" and "after" call both report `possible_stale_content:
true` (or an `Age` header that hasn't reset), that's strong evidence the
real cause was a caching layer serving stale HTML to the loopback
fetch — not a scanning bug. If both calls report fresh, uncached
content and the miss still happens, that would point back to something
in the DOM-walk logic and should be re-opened as a bug.

## HTML parsing hardening (new in 1.1.0)

All three `DOMDocument::loadHTML()` calls now pass explicit
`LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_NOBLANKS` flags. This wasn't
confirmed as the cause of anything in the build2 test, but it's cheap
insurance against a busy/build2-style page (calendar widgets, tooltip
libraries, etc.) producing enough non-fatal libxml warnings/errors to
interfere with parsing.

## Wiring into the existing wp-mcp / Oxygen ability layer

This plugin does NOT register MCP abilities itself — it only adds plain
WP REST routes. Whoever maintains the wp-mcp bridge should add two thin
wrapper abilities:

```
oxygen-audit-page          { post_id }  -> GET .../audit-page/{post_id}
oxygen-find-unused-classes { post_id }  -> GET .../unused-classes/{post_id}
```

Suggested playbook rule once wired up (already added to the WordPress
Sites playbook in prose form — this makes it enforceable):

- Before writing new CSS for a section that looks unstyled, call
  `oxygen-find-unused-classes` first — there's a real chance a matching
  class already exists from an earlier attempt.
- After any edit that touches classes, layout, or styling, call
  `oxygen-audit-page` before reporting the fix as done.
- If a flag looks wrong (missed or false positive), check
  `possible_stale_content` before assuming the scan logic is broken —
  it may mean the page needs to be re-fetched, or a cache purged,
  before the audit re-run means anything.

## Honest limitations

This is static analysis, not a real browser or a CSS cascade engine.
It does not resolve specificity/`!important`/rule order, does not
evaluate `@media` queries conditionally, does not account for values
inherited from ancestor elements, and only understands two selector
shapes (`.class` and `.class tag`) for property-matching — more complex
selectors still count toward the "is this class used anywhere"
unused-class check, just not the per-element property check.

The Oxygen-stylesheet filter is a hint-pattern match on the URL, not a
guarantee — a site whose Oxygen CSS is served from a URL that happens
not to contain `oxygen`/`ct-builder`/`oxy-` will fall back to scanning
everything (noisy but not silent).

The cache diagnostics report what headers were present on one fetch;
they cannot prove a caching layer was the cause, only make it visible
enough to correlate against a "before/after" test.

Treat every flag as "look here first," not as proven-broken. For
anything it doesn't flag, a live visual check is still worth doing
before calling a fix done — this narrows where to look, it doesn't
replace looking.

## Debugging a specific class (new in 1.2.0)

`GET /audit-page/{post_id}?debug_class=some-class-name` adds a
`debug_class_lookup` field to the response answering, for that exact
class string: is there a CSS rule for it anywhere in scanned CSS, and
which live elements (if any) currently carry it in their class
attribute — independent of whether the main scan flagged anything.
Use this any time a specific class is "supposed" to be flagged/unflagged
and isn't, instead of guessing why from the outside. The response
includes a plain-English `interpretation` of what the three possible
outcomes mean (edit never landed on the page / class isn't actually
unknown because a rule does match it / genuine detection bug).

## Core-noise filtering for unused-classes (new in 1.2.0)

`unused-classes` now also filters out common WordPress/Gutenberg core
utility classes (`has-*-color`, `is-layout-*`, `wp-*`, `align*`, etc.)
by default — these are enqueued globally by WordPress/Gutenberg, not
authored by Oxygen or left over from a prior build, and will always
look "unused" on a single Oxygen page. `core_noise_filtered_count`
reports how many were removed; pass `?include_core_noise=1` to see them
anyway.

## Verifying a CSS variable override actually rendered (new in 1.3.0)

`GET /verify-variable-override/{post_id}?element_id=<int>&variable=<name>[&expected_value=<value>]`

Background: the Test 1-6 investigation on build2.churchwebglobal.com found
that Oxygen 6.2's real per-element design-control tool is
`oxygen-set-element-variable-overrides` (a scoped CSS custom property),
not `oxygen-edit-post`'s `design.*` (which is legitimately empty by
architecture, not a bug). That write tool returning `success: true` is
not proof the override reached the rendered page — the same
"API succeeded, page didn't visibly change" gap that caused the original
BBI Argentina incidents this whole plugin exists to catch.

This endpoint checks, on the LIVE page: does the element (matched by its
Oxygen-generated `oxy-*-{post_id}-{element_id}` class) actually carry
`--<variable>` — inline on its own `style` attribute, or in a scanned CSS
rule targeting it — and if `expected_value` is given, does the value
match. It also reports whether `var(--<variable>)` is referenced
*anywhere* in scanned CSS, since a variable that's set but never consumed
by anything has no visible effect even though the write "succeeded."

Use this after every `oxygen-set-element-variable-overrides` call before
reporting a styling change as done, the same way `debug_class` is used
after a class-based edit.

## Scoping flags to a page's own content vs. global header/footer (new in 1.4.0)

Found during the real-complexity homepage build test (2026-09-09,
build2.churchwebglobal.com, page 115): `audit-page` walks the entire
rendered page, which includes the site's global header/footer template —
so a flag caused by site-wide chrome (markup shared across every page)
showed up attributed to that one page's audit, reading as a false
positive unless you knew to expect it.

Every flag in `audit-page`'s response now carries a `region` field:
`header`, `footer`, `nav`, or `main_content` — detected by walking each
flagged element's ancestors for a `<header>`/`<footer>`/`<nav>` tag or an
id/class containing a common global-region marker (`site-header`,
`masthead`, `site-footer`, `colophon`, `global-header`, `global-footer`).
This is additive — existing callers reading `flags` see the same list,
just with one more field per entry.

The response also now reports `elements_flagged_main_content` and
`elements_flagged_global_regions` as an explicit breakdown, and a new
opt-in param `?exclude_global_regions=1` filters `flags` down to
`main_content` only, for when you're specifically auditing one page's own
build work and don't want global chrome noise in the list.

This is heuristic region detection, not a guarantee. A theme with no
semantic `<header>`/`<footer>` tags and none of the listed id/class
markers will have everything fall through to `main_content` — the safe
default, since it means nothing gets silently hidden by an unrecognized
theme. If a theme uses different naming, extend
`artivio_oxygen_audit_global_region_markers()` in the plugin.

## Changelog

**1.4.0**
- Added: `region` field (`header`/`footer`/`nav`/`main_content`) on every
  `audit-page` flag, plus `elements_flagged_main_content` /
  `elements_flagged_global_regions` counts and an opt-in
  `?exclude_global_regions=1` filter. Fixes the false-positive gap found
  when global header/footer content bled into a per-page audit's flags.
  See "Scoping flags to a page's own content vs. global header/footer"
  above.

**1.3.0**
- Added: `?element_id=&variable=&expected_value=` on a new
  `/verify-variable-override/{post_id}` endpoint — confirms a CSS
  variable override set via `oxygen-set-element-variable-overrides`
  actually reached the rendered page, and whether anything consumes it.
  See "Verifying a CSS variable override actually rendered" above.

**1.2.0**
- Added: `?debug_class=<name>` on `audit-page` — direct diagnosis of why
  a specific class was or wasn't flagged, instead of reasoning about it
  from outside. See "Debugging a specific class" above.
- Added: core-utility-class filtering on `unused-classes` (WordPress/
  Gutenberg `has-*`, `is-layout-*`, `wp-*`, `align*`, etc.), on by
  default, togglable via `?include_core_noise=1`. This was most of the
  87 results still left after the 1.1.0 stylesheet-scoping fix.

**1.1.0**
- Fixed: `unused-classes` no longer scans every enqueued stylesheet on
  the page — filtered to Oxygen-hinted stylesheets (with fallback to
  all if none match), eliminating the noise that produced 568 false
  "unused" results in testing.
- Added: `stylesheets_scanned`, `oxygen_stylesheet_filter_matched`,
  `cache_headers_seen`, `possible_stale_content`,
  `elements_with_class_scanned` fields on both endpoints, to make the
  scan's inputs auditable instead of opaque.
- Hardened: explicit libxml flags on all `loadHTML()` calls.
- Investigated but not changed: disputed a test report's claim that
  `audit-page` structurally can't reach Oxygen content elements — the
  same report's own data contradicts it. Added cache diagnostics
  instead of a blind fix; see "Cache diagnostics" above.

**1.0.0**
- Initial release: `status`, `audit-page`, `unused-classes` endpoints.
