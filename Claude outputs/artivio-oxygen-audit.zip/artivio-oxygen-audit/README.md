# Artivio Oxygen Audit

A small, read-only WordPress plugin that gives an AI agent a way to check
"did my Oxygen class/style edit actually take effect on the live page?"
without needing a browser. Built directly from three incidents where Theo
reported a fix as done while a class was silently detached from its CSS
rule, then hardened after a real-world test on build2.churchwebglobal.com
(Noah) surfaced two more issues — see Changelog below.

## Install

1. Upload the `artivio-oxygen-audit` folder to `wp-content/plugins/` on
   the target site (or zip it and use **Plugins → Add New → Upload
   Plugin** in wp-admin).
2. Activate it from **Plugins**.
3. No settings page — it just exposes three REST endpoints, authenticated
   the same way as any other WP REST call (Application Passwords over
   Basic Auth, or a logged-in session).

## Endpoints

- `GET /wp-json/artivio-oxygen-audit/v1/status`
  Health check — plugin version, WP version, active theme.

- `GET /wp-json/artivio-oxygen-audit/v1/audit-page/{post_id}`
  Fetches the LIVE rendered page and flags elements where:
  - one of its classes doesn't exist in any loaded stylesheet at all
    (a typo'd or never-written class), or
  - it's a section/div-like container with none of its own classes
    declaring a background, or
  - it visibly contains text but none of its own classes declare a
    text color (the "white text on white background" bug).

  Also returns, for transparency and debugging:
  - `elements_with_class_scanned` — total elements-with-a-class the
    xpath walk encountered on this fetch.
  - `stylesheets_scanned` / `oxygen_stylesheet_filter_matched` — see
    "Stylesheet filtering" below.
  - `cache_headers_seen` / `possible_stale_content` — see "Cache
    diagnostics" below.

- `GET /wp-json/artivio-oxygen-audit/v1/unused-classes/{post_id}`
  Lists every class-based CSS rule on the page's stylesheets that
  currently matches **zero** elements on the page — i.e. CSS left over
  from an earlier build attempt, sitting there unused and reusable by
  name instead of writing something new from scratch. Same
  `stylesheets_scanned` / `oxygen_stylesheet_filter_matched` /
  `cache_headers_seen` / `possible_stale_content` fields are included.

## Stylesheet filtering (new in 1.1.0)

v1.0.0 collected CSS from **every** stylesheet enqueued on the page —
WP core, plugins like The Events Calendar, tooltipster, etc. — not just
the Oxygen-authored CSS. On a real site with a normal plugin stack this
buried the signal: a test on build2.churchwebglobal.com returned 568
"unused classes," almost all of them noise from unrelated plugin CSS.

v1.1.0 filters `<link rel=stylesheet>` tags to only the ones whose URL
looks Oxygen-related (contains `oxygen`, `ct-builder`, or `oxy-`).
Inline `<style>` blocks are still always scanned, since Oxygen writes a
lot of its per-post CSS inline. If nothing on the page matches the
Oxygen hint patterns, the filter automatically falls back to scanning
everything (better to be noisy than silent) and reports
`oxygen_stylesheet_filter_matched: false` so you know the fallback fired.

`stylesheets_scanned` always lists exactly which stylesheet URLs were
actually parsed, so a report can be checked against what was on the page.

## Cache diagnostics (new in 1.1.0)

A build2.churchwebglobal.com test also reported `audit-page` failing to
flag a typo'd class before a fix, and then (expectedly, correctly) not
flagging it after the fix. The stated root cause in that report —
"audit-page only scans `<body>`/`<a>`, never reaches Oxygen content
elements" — doesn't fit the rest of that same report: the identical
unscoped xpath (`//*[@class]`) *did* find `div.oxy-container-9-103` in
the very next (after-fix) call. A scanner that structurally can't reach
Oxygen divs shouldn't suddenly reach one two calls later with no code
change in between.

Rather than guess at a fix for a cause that doesn't match the evidence,
1.1.0 adds instrumentation so the next test can tell us which
explanation is right:
- `cache_headers_seen` — whatever `Age`, `X-Cache`, `CF-Cache-Status`,
  `Cache-Control`, `X-Litespeed-Cache`, `X-Nginx-Cache` headers came
  back on the server-side loopback fetch of the page.
- `possible_stale_content` — `true` if `Age > 5` or any of the above
  headers contains "hit" (case-insensitive) — a heuristic flag that a
  caching layer served an older snapshot of the page rather than the
  one that was just saved.

If a "before" and "after" call both report `possible_stale_content:
true` (or an `Age` header that hasn't reset), that's strong evidence the
real cause was a caching layer serving stale HTML to the loopback
fetch — not a scanning bug. If both calls report fresh, uncached
content and the miss still happens, that would point back to something
in the DOM-walk logic and should be re-opened as a bug.

## HTML parsing hardening (new in 1.1.0)

All three `DOMDocument::loadHTML()` calls now pass explicit
`LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_NOBLANKS` flags. This wasn't
confirmed as the cause of anything in the build2 test, but it's cheap
insurance against a busy/build2-style page (calendar widgets, tooltip
libraries, etc.) producing enough non-fatal libxml warnings/errors to
interfere with parsing.

## Wiring into the existing wp-mcp / Oxygen ability layer

This plugin does NOT register MCP abilities itself — it only adds plain
WP REST routes. Whoever maintains the wp-mcp bridge should add two thin
wrapper abilities:

```
oxygen-audit-page          { post_id }  -> GET .../audit-page/{post_id}
oxygen-find-unused-classes { post_id }  -> GET .../unused-classes/{post_id}
```

Suggested playbook rule once wired up (already added to the WordPress
Sites playbook in prose form — this makes it enforceable):

- Before writing new CSS for a section that looks unstyled, call
  `oxygen-find-unused-classes` first — there's a real chance a matching
  class already exists from an earlier attempt.
- After any edit that touches classes, layout, or styling, call
  `oxygen-audit-page` before reporting the fix as done.
- If a flag looks wrong (missed or false positive), check
  `possible_stale_content` before assuming the scan logic is broken —
  it may mean the page needs to be re-fetched, or a cache purged,
  before the audit re-run means anything.

## Honest limitations

This is static analysis, not a real browser or a CSS cascade engine.
It does not resolve specificity/`!important`/rule order, does not
evaluate `@media` queries conditionally, does not account for values
inherited from ancestor elements, and only understands two selector
shapes (`.class` and `.class tag`) for property-matching — more complex
selectors still count toward the "is this class used anywhere"
unused-class check, just not the per-element property check.

The Oxygen-stylesheet filter is a hint-pattern match on the URL, not a
guarantee — a site whose Oxygen CSS is served from a URL that happens
not to contain `oxygen`/`ct-builder`/`oxy-` will fall back to scanning
everything (noisy but not silent).

The cache diagnostics report what headers were present on one fetch;
they cannot prove a caching layer was the cause, only make it visible
enough to correlate against a "before/after" test.

Treat every flag as "look here first," not as proven-broken. For
anything it doesn't flag, a live visual check is still worth doing
before calling a fix done — this narrows where to look, it doesn't
replace looking.

## Changelog

**1.1.0**
- Fixed: `unused-classes` no longer scans every enqueued stylesheet on
  the page — filtered to Oxygen-hinted stylesheets (with fallback to
  all if none match), eliminating the noise that produced 568 false
  "unused" results in testing.
- Added: `stylesheets_scanned`, `oxygen_stylesheet_filter_matched`,
  `cache_headers_seen`, `possible_stale_content`,
  `elements_with_class_scanned` fields on both endpoints, to make the
  scan's inputs auditable instead of opaque.
- Hardened: explicit libxml flags on all `loadHTML()` calls.
- Investigated but not changed: disputed a test report's claim that
  `audit-page` structurally can't reach Oxygen content elements — the
  same report's own data contradicts it. Added cache diagnostics
  instead of a blind fix; see "Cache diagnostics" above.

**1.0.0**
- Initial release: `status`, `audit-page`, `unused-classes` endpoints.
