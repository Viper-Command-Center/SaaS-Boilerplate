# Artivio Oxygen Audit

A small, read-only WordPress plugin that gives an AI agent a way to check
"did my Oxygen class/style edit actually take effect on the live page?"
without needing a browser. Built directly from three incidents tonight
where Theo reported a fix as done while a class was silently detached
from its CSS rule.

## Install

1. Upload the `artivio-oxygen-audit` folder to `wp-content/plugins/` on
   the target site (or zip it and use **Plugins → Add New → Upload
   Plugin** in wp-admin).
2. Activate it from **Plugins**.
3. No settings page — it just exposes two REST endpoints, authenticated
   the same way as any other WP REST call (Application Passwords over
   Basic Auth, or a logged-in session).

## Endpoints

- `GET /wp-json/artivio-oxygen-audit/v1/status`
  Health check — plugin version, WP version, active theme.

- `GET /wp-json/artivio-oxygen-audit/v1/audit-page/{post_id}`
  Fetches the LIVE rendered page and flags elements where:
  - one of its classes doesn't exist in any loaded stylesheet at all
    (a typo'd or never-written class), or
  - it's a section/div-like container with none of its own classes
    declaring a background, or
  - it visibly contains text but none of its own classes declare a
    text color (the "white text on white background" bug from tonight).

- `GET /wp-json/artivio-oxygen-audit/v1/unused-classes/{post_id}`
  Lists every class-based CSS rule on the page's stylesheets that
  currently matches **zero** elements on the page — i.e. CSS left over
  from an earlier build attempt, sitting there unused and reusable by
  name instead of writing something new from scratch. This is exactly
  what the `hww-*` design system was tonight before we found it.

## Wiring into the existing wp-mcp / Oxygen ability layer

This plugin does NOT register MCP abilities itself — it only adds plain
WP REST routes. Whoever maintains the wp-mcp bridge should add two thin
wrapper abilities:

```
oxygen-audit-page          { post_id }  -> GET .../audit-page/{post_id}
oxygen-find-unused-classes { post_id }  -> GET .../unused-classes/{post_id}
```

Suggested playbook rule once wired up (already added to the WordPress
Sites playbook in prose form — this makes it enforceable):

- Before writing new CSS for a section that looks unstyled, call
  `oxygen-find-unused-classes` first — there's a real chance a matching
  class already exists from an earlier attempt.
- After any edit that touches classes, layout, or styling, call
  `oxygen-audit-page` before reporting the fix as done.

## Honest limitations

This is static analysis, not a real browser or a CSS cascade engine.
It does not resolve specificity/`!important`/rule order, does not
evaluate `@media` queries conditionally, does not account for values
inherited from ancestor elements, and only understands two selector
shapes (`.class` and `.class tag`) for property-matching — more complex
selectors still count toward the "is this class used anywhere"
unused-class check, just not the per-element property check.

Treat every flag as "look here first," not as proven-broken. For
anything it doesn't flag, a live visual check is still worth doing
before calling a fix done — this narrows where to look, it doesn't
replace looking.
