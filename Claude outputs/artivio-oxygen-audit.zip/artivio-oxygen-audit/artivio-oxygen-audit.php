<?php
/**
 * Plugin Name:       Artivio Oxygen Audit
 * Description:       Read-only diagnostic endpoints for AI agents editing Oxygen Builder pages. Answers "did my class/style edit actually take effect on the live page?" without needing a browser.
 * Version:           1.1.0
 * Author:            Artivio
 * Requires PHP:      7.4
 *
 * ---------------------------------------------------------------------------
 * CHANGELOG
 * ---------------------------------------------------------------------------
 * 1.1.0 — Fixes from first real test (build2.churchwebglobal.com, page #9,
 *         run by Noah):
 *   - unused-classes was reporting every class in every enqueued
 *     stylesheet (WordPress core, plugins, third-party JS libraries) —
 *     568 results on a 3-element test page, signal completely buried in
 *     noise. Fixed: CSS collection now scans inline <style> blocks plus
 *     only <link> stylesheets whose URL looks Oxygen-authored (falls
 *     back to scanning everything, clearly flagged, if none match — see
 *     $oxygen_hint_patterns below; adjust if your site's Oxygen CSS is
 *     served from a different path).
 *   - Both endpoints now report exactly which stylesheets were scanned
 *     (`stylesheets_scanned`), so it's never a silent guess.
 *   - Both endpoints now surface any cache-related response headers seen
 *     on the fetch (Age, X-Cache, CF-Cache-Status, Cache-Control) plus a
 *     `possible_stale_content` warning when one of those looks like a
 *     cache HIT. This directly targets the open question from the first
 *     test: whether a typo'd test class went undetected because the
 *     audited HTML was stale, not because the scanner skipped content
 *     elements (the xpath has never been scoped to body/links only —
 *     see NOTE below).
 *   - Hardened HTML parsing with explicit libxml flags
 *     (LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_NOBLANKS) — cheap
 *     insurance against malformed/deeply-nested builder markup silently
 *     truncating the parsed DOM, even though this wasn't confirmed as
 *     the actual cause this time.
 *
 * NOTE on the first test's Bug-1 failure: the report attributed it to
 * "the audit only scans <body> and skip-links, not Oxygen content
 * elements." That doesn't fully fit the evidence — the xpath used
 * (`//*[@class]`) is unscoped, and the SAME code path correctly found
 * `div.oxy-container-9-103` on the very next call. A structural
 * "can't reach Oxygen divs" bug wouldn't explain finding one Oxygen div
 * and not another with identical logic. The more consistent explanation
 * is that the two calls fetched two different snapshots of the page
 * (stale vs fresh) — hence the cache diagnostics added in this version,
 * rather than a content-scanning fix that the evidence doesn't actually
 * point to. Re-test with 1.1.0 and check `cache_headers_seen` /
 * `possible_stale_content` in the response before assuming either
 * explanation — this version is built to tell you which one it was.
 *
 * ---------------------------------------------------------------------------
 * WHAT THIS PLUGIN IS FOR
 * ---------------------------------------------------------------------------
 * Oxygen Builder elements carry classes, and those classes only mean
 * something if a matching CSS rule exists AND is actually attached to the
 * element. Nothing in the normal Oxygen MCP toolset verifies that pairing
 * after an edit. This plugin exposes two REST endpoints that do real,
 * callable, structural analysis of a LIVE rendered page (not the builder's
 * internal JSON), so an agent can self-check before declaring a fix done:
 *
 *   GET /wp-json/artivio-oxygen-audit/v1/audit-page/{post_id}
 *   GET /wp-json/artivio-oxygen-audit/v1/unused-classes/{post_id}
 *   GET /wp-json/artivio-oxygen-audit/v1/status
 *
 * ---------------------------------------------------------------------------
 * HONEST LIMITATIONS (read before trusting this blindly)
 * ---------------------------------------------------------------------------
 * This is deliberately a lightweight static-analysis tool, NOT a headless
 * browser and NOT a real CSS cascade engine. It does NOT:
 *   - Resolve specificity, !important, or rule ORDER precisely.
 *   - Evaluate @media queries conditionally (a mobile-only rule still
 *     counts as "this class has a background-color rule").
 *   - Resolve inherited values from ancestor elements — a text element
 *     with its color set directly (not inherited) will NOT be flagged as
 *     invisible against its parent's background; this tool only checks
 *     whether an element's OWN classes declare a property, not whether
 *     the resulting color is legible against whatever is behind it.
 *   - Understand selectors more complex than ".class" or ".class tag".
 *   - See anything a caching layer decided not to serve fresh. This tool
 *     fetches the page the same way any HTTP client would — if the site
 *     has a page cache/CDN in front of it, a just-made edit may not be
 *     visible yet. Check `possible_stale_content` in the response.
 *
 * Treat a flag from this tool as "look here first", not as ground truth.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'ARTIVIO_OXYGEN_AUDIT_VERSION', '1.1.0' );
define( 'ARTIVIO_OXYGEN_AUDIT_NS', 'artivio-oxygen-audit/v1' );

/**
 * Substrings used to recognize an Oxygen-authored stylesheet URL. Adjust
 * this list if a site serves its Oxygen CSS from a different path pattern
 * — the plugin will tell you (via `stylesheets_scanned` /
 * `oxygen_stylesheet_filter_matched`) whether any stylesheet matched, so
 * it's obvious when this list needs updating for a given host.
 */
function artivio_oxygen_audit_hint_patterns() {
	return array( 'oxygen', 'ct-builder', 'oxy-' );
}

add_action( 'rest_api_init', 'artivio_oxygen_audit_register_routes' );

function artivio_oxygen_audit_register_routes() {
	register_rest_route(
		ARTIVIO_OXYGEN_AUDIT_NS,
		'/status',
		array(
			'methods'             => 'GET',
			'callback'            => 'artivio_oxygen_audit_status',
			'permission_callback' => 'artivio_oxygen_audit_permission_check',
		)
	);

	register_rest_route(
		ARTIVIO_OXYGEN_AUDIT_NS,
		'/audit-page/(?P<id>\d+)',
		array(
			'methods'             => 'GET',
			'callback'            => 'artivio_oxygen_audit_page',
			'permission_callback' => 'artivio_oxygen_audit_permission_check',
			'args'                => array(
				'id' => array(
					'validate_callback' => function ( $param ) {
						return is_numeric( $param );
					},
				),
			),
		)
	);

	register_rest_route(
		ARTIVIO_OXYGEN_AUDIT_NS,
		'/unused-classes/(?P<id>\d+)',
		array(
			'methods'             => 'GET',
			'callback'            => 'artivio_oxygen_audit_unused_classes',
			'permission_callback' => 'artivio_oxygen_audit_permission_check',
			'args'                => array(
				'id' => array(
					'validate_callback' => function ( $param ) {
						return is_numeric( $param );
					},
				),
			),
		)
	);
}

function artivio_oxygen_audit_permission_check() {
	return current_user_can( 'edit_posts' );
}

function artivio_oxygen_audit_status( WP_REST_Request $request ) {
	return new WP_REST_Response(
		array(
			'plugin_version' => ARTIVIO_OXYGEN_AUDIT_VERSION,
			'wp_version'     => get_bloginfo( 'version' ),
			'active_theme'   => wp_get_theme()->get( 'Name' ),
			'site_url'       => site_url(),
		),
		200
	);
}

/**
 * Headers worth surfacing to help an agent tell "this might be a stale
 * cached copy" from "this is genuinely what's live right now."
 */
function artivio_oxygen_audit_cache_headers( $response ) {
	$watched = array( 'age', 'x-cache', 'cf-cache-status', 'cache-control', 'x-litespeed-cache', 'x-nginx-cache' );
	$seen    = array();
	foreach ( $watched as $header ) {
		$value = wp_remote_retrieve_header( $response, $header );
		if ( ! empty( $value ) ) {
			$seen[ $header ] = $value;
		}
	}
	return $seen;
}

function artivio_oxygen_audit_looks_stale( $cache_headers ) {
	foreach ( $cache_headers as $header => $value ) {
		$value_lc = strtolower( is_array( $value ) ? implode( ',', $value ) : $value );
		if ( 'age' === $header && is_numeric( $value ) && (int) $value > 5 ) {
			return true; // Served from cache more than 5s old.
		}
		if ( false !== strpos( $value_lc, 'hit' ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Fetch a post's live rendered HTML via an internal loopback request.
 * Returns [ $html, $cache_headers, $error ].
 */
function artivio_oxygen_audit_fetch_page( $post_id ) {
	$post = get_post( $post_id );
	if ( ! $post ) {
		return array( null, array(), 'post_not_found' );
	}

	$url = get_permalink( $post_id );
	if ( ! $url ) {
		return array( null, array(), 'no_permalink' );
	}

	$url = add_query_arg( 'artivio_audit_nocache', time() . '-' . wp_rand( 1000, 9999 ), $url );

	$response = wp_remote_get(
		$url,
		array(
			'timeout'   => 20,
			'sslverify' => false,
			'headers'   => array(
				'Cache-Control' => 'no-cache, no-store, must-revalidate',
				'Pragma'        => 'no-cache',
			),
		)
	);

	if ( is_wp_error( $response ) ) {
		return array( null, array(), 'fetch_failed: ' . $response->get_error_message() );
	}

	$html = wp_remote_retrieve_body( $response );
	if ( empty( $html ) ) {
		return array( null, array(), 'empty_response' );
	}

	$cache_headers = artivio_oxygen_audit_cache_headers( $response );

	return array( $html, $cache_headers, null );
}

/**
 * Pull stylesheet text out of a page: inline <style> blocks always, plus
 * external <link rel="stylesheet"> only when the URL matches one of the
 * Oxygen hint patterns — this is what keeps unused-classes from drowning
 * in WordPress-core/plugin/vendor CSS. If NOTHING matches the hint
 * patterns, falls back to scanning everything so the tool never silently
 * returns nothing; `oxygen_stylesheet_filter_matched` tells you which
 * happened.
 *
 * Returns [ $css_text, $stylesheets_scanned, $filter_matched ]
 */
function artivio_oxygen_audit_collect_css( $html, $base_url ) {
	libxml_use_internal_errors( true );
	$dom = new DOMDocument();
	$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html, LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_NOBLANKS );
	libxml_clear_errors();

	$inline_chunks    = array();
	foreach ( $dom->getElementsByTagName( 'style' ) as $style_node ) {
		$inline_chunks[] = $style_node->textContent;
	}

	$hint_patterns    = artivio_oxygen_audit_hint_patterns();
	$candidate_links  = array(); // href => matched-hint (bool)
	foreach ( $dom->getElementsByTagName( 'link' ) as $link_node ) {
		$rel = strtolower( (string) $link_node->getAttribute( 'rel' ) );
		if ( 'stylesheet' !== $rel ) {
			continue;
		}
		$href = $link_node->getAttribute( 'href' );
		if ( empty( $href ) ) {
			continue;
		}
		if ( 0 === strpos( $href, '//' ) ) {
			$href = 'https:' . $href;
		} elseif ( 0 === strpos( $href, '/' ) ) {
			$parsed = wp_parse_url( $base_url );
			$href   = $parsed['scheme'] . '://' . $parsed['host'] . $href;
		}

		$matched = false;
		foreach ( $hint_patterns as $pattern ) {
			if ( false !== stripos( $href, $pattern ) ) {
				$matched = true;
				break;
			}
		}
		$candidate_links[ $href ] = $matched;
	}

	$matched_links = array_keys( array_filter( $candidate_links ) );
	$filter_matched = ! empty( $matched_links );
	$links_to_fetch = $filter_matched ? $matched_links : array_keys( $candidate_links );

	$css_chunks     = $inline_chunks;
	$stylesheets_scanned = array();
	if ( ! empty( $inline_chunks ) ) {
		$stylesheets_scanned[] = 'inline <style> blocks (' . count( $inline_chunks ) . ')';
	}

	foreach ( $links_to_fetch as $href ) {
		$css_response = wp_remote_get( $href, array( 'timeout' => 15, 'sslverify' => false ) );
		if ( ! is_wp_error( $css_response ) ) {
			$css_chunks[]           = wp_remote_retrieve_body( $css_response );
			$stylesheets_scanned[]  = $href;
		}
	}

	return array( implode( "\n", $css_chunks ), $stylesheets_scanned, $filter_matched );
}

function artivio_oxygen_audit_parse_css( $css_text ) {
	$class_props      = array();
	$all_class_tokens = array();

	$css_text = preg_replace( '!/\*.*?\*/!s', '', $css_text );

	if ( ! preg_match_all( '/([^{}]+)\{([^{}]*)\}/s', $css_text, $matches, PREG_SET_ORDER ) ) {
		return array( $class_props, $all_class_tokens );
	}

	foreach ( $matches as $match ) {
		$selector_list = trim( $match[1] );
		$declarations  = trim( $match[2] );

		if ( '' === $selector_list || '' === $declarations || 0 === strpos( $selector_list, '@' ) ) {
			continue;
		}

		if ( preg_match_all( '/\.([a-zA-Z0-9_-]+)/', $selector_list, $class_hits ) ) {
			foreach ( $class_hits[1] as $cls ) {
				$all_class_tokens[ $cls ] = true;
			}
		}

		$props = array();
		foreach ( explode( ';', $declarations ) as $decl ) {
			$decl = trim( $decl );
			if ( '' === $decl || false === strpos( $decl, ':' ) ) {
				continue;
			}
			list( $prop ) = explode( ':', $decl, 2 );
			$props[]      = strtolower( trim( $prop ) );
		}
		if ( empty( $props ) ) {
			continue;
		}

		foreach ( explode( ',', $selector_list ) as $selector ) {
			$selector = trim( $selector );

			if ( preg_match( '/^\.([a-zA-Z0-9_-]+)$/', $selector, $m ) ) {
				$cls = $m[1];
				foreach ( $props as $prop ) {
					$class_props[ $cls ][ $prop ][] = trim( $selector_list ) . ' { ' . trim( $declarations ) . ' }';
				}
				continue;
			}

			if ( preg_match( '/^\.([a-zA-Z0-9_-]+)\s+([a-zA-Z][a-zA-Z0-9]*)$/', $selector, $m ) ) {
				$cls    = $m[1];
				$bucket = 'descendant_' . strtolower( $m[2] );
				foreach ( $props as $prop ) {
					$class_props[ $cls ][ $bucket . ':' . $prop ][] = trim( $selector_list ) . ' { ' . trim( $declarations ) . ' }';
				}
				continue;
			}
		}
	}

	return array( $class_props, $all_class_tokens );
}

function artivio_oxygen_audit_watched_properties() {
	return array( 'background-color', 'background', 'padding', 'color' );
}

function artivio_oxygen_audit_page( WP_REST_Request $request ) {
	$post_id = (int) $request['id'];

	list( $html, $cache_headers, $error ) = artivio_oxygen_audit_fetch_page( $post_id );
	if ( $error ) {
		return new WP_REST_Response( array( 'error' => $error ), 400 );
	}

	list( $css_text, $stylesheets_scanned, $filter_matched ) = artivio_oxygen_audit_collect_css( $html, get_permalink( $post_id ) );
	list( $class_props, $all_class_tokens )                  = artivio_oxygen_audit_parse_css( $css_text );
	$watched = artivio_oxygen_audit_watched_properties();

	libxml_use_internal_errors( true );
	$dom = new DOMDocument();
	$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html, LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_NOBLANKS );
	libxml_clear_errors();

	$xpath    = new DOMXPath( $dom );
	$elements = $xpath->query( '//*[@class]' );

	$results       = array();
	$flagged_count = 0;
	$scanned_count = 0;

	foreach ( $elements as $el ) {
		$class_attr = trim( $el->getAttribute( 'class' ) );
		if ( '' === $class_attr ) {
			continue;
		}
		$scanned_count++;
		$classes = preg_split( '/\s+/', $class_attr );

		$checkable_classes = array_filter(
			$classes,
			function ( $c ) {
				return ! preg_match( '/^oxy-(container|text|text-link)-\d+-\d+$/', $c )
					&& 'oxy-container' !== $c && 'oxy-text' !== $c && 'oxy-text-link' !== $c;
			}
		);

		if ( empty( $checkable_classes ) ) {
			continue;
		}

		$unknown_classes = array();
		$has_property     = array();
		foreach ( $watched as $prop ) {
			$has_property[ $prop ] = false;
		}

		foreach ( $checkable_classes as $cls ) {
			if ( ! isset( $all_class_tokens[ $cls ] ) ) {
				$unknown_classes[] = $cls;
				continue;
			}
			if ( isset( $class_props[ $cls ] ) ) {
				foreach ( $watched as $prop ) {
					if ( isset( $class_props[ $cls ][ $prop ] ) ) {
						$has_property[ $prop ] = true;
					}
				}
			}
		}

		$missing = array_keys( array_filter( $has_property, function ( $v ) {
			return ! $v;
		} ) );

		$tag_lc         = strtolower( $el->tagName );
		$is_container   = in_array( $tag_lc, array( 'section', 'div' ), true );
		$is_text_bearer = in_array( $tag_lc, array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'span', 'a', 'li' ), true );
		$has_text       = '' !== trim( $el->textContent );

		$noteworthy = ! empty( $unknown_classes )
			|| ( $is_container && ! $has_property['background-color'] && ! $has_property['background'] )
			|| ( $is_text_bearer && $has_text && ! $has_property['color'] );

		if ( ! $noteworthy ) {
			continue;
		}

		$flagged_count++;
		$results[] = array(
			'tag'                       => $tag_lc,
			'classes'                   => array_values( $classes ),
			'text_preview'              => mb_substr( trim( preg_replace( '/\s+/', ' ', $el->textContent ) ), 0, 60 ),
			'unknown_classes'           => array_values( $unknown_classes ),
			'missing_from_own_classes'  => array_values( $missing ),
			'note'                      => 'Flagged heuristically — check ancestors before assuming this is broken (see plugin limitations).',
		);
	}

	return new WP_REST_Response(
		array(
			'post_id'                          => $post_id,
			'audited_url'                       => get_permalink( $post_id ),
			'elements_with_class_scanned'       => $scanned_count,
			'elements_flagged'                  => $flagged_count,
			'flags'                             => $results,
			'stylesheets_scanned'                => $stylesheets_scanned,
			'oxygen_stylesheet_filter_matched'   => $filter_matched,
			'cache_headers_seen'                 => $cache_headers,
			'possible_stale_content'             => artivio_oxygen_audit_looks_stale( $cache_headers ),
			'limitations'                        => 'Heuristic static analysis: no cascade/specificity resolution, no media-query awareness, no ancestor inheritance. See plugin header docblock.',
		),
		200
	);
}

function artivio_oxygen_audit_unused_classes( WP_REST_Request $request ) {
	$post_id = (int) $request['id'];

	list( $html, $cache_headers, $error ) = artivio_oxygen_audit_fetch_page( $post_id );
	if ( $error ) {
		return new WP_REST_Response( array( 'error' => $error ), 400 );
	}

	list( $css_text, $stylesheets_scanned, $filter_matched ) = artivio_oxygen_audit_collect_css( $html, get_permalink( $post_id ) );
	list( $class_props, $all_class_tokens )                  = artivio_oxygen_audit_parse_css( $css_text );

	libxml_use_internal_errors( true );
	$dom = new DOMDocument();
	$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html, LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_NOBLANKS );
	libxml_clear_errors();

	$xpath        = new DOMXPath( $dom );
	$elements     = $xpath->query( '//*[@class]' );
	$used_classes = array();

	foreach ( $elements as $el ) {
		$class_attr = trim( $el->getAttribute( 'class' ) );
		if ( '' === $class_attr ) {
			continue;
		}
		foreach ( preg_split( '/\s+/', $class_attr ) as $cls ) {
			$used_classes[ $cls ] = true;
		}
	}

	$unused = array();
	foreach ( $all_class_tokens as $cls => $_true ) {
		if ( isset( $used_classes[ $cls ] ) ) {
			continue;
		}
		$snippets = array();
		if ( isset( $class_props[ $cls ] ) ) {
			foreach ( $class_props[ $cls ] as $prop => $rules ) {
				$snippets[] = $rules[0];
			}
		}
		$unused[] = array(
			'class'   => $cls,
			'rules'   => array_slice( array_unique( $snippets ), 0, 5 ),
			'meaning' => 'This class has a CSS rule (in a scanned Oxygen stylesheet) but is not applied to any element currently on this page — likely leftover from an earlier build attempt. Consider reusing it by name before writing a new class.',
		);
	}

	usort(
		$unused,
		function ( $a, $b ) {
			return count( $b['rules'] ) <=> count( $a['rules'] );
		}
	);

	return new WP_REST_Response(
		array(
			'post_id'                          => $post_id,
			'audited_url'                       => get_permalink( $post_id ),
			'unused_class_count'                 => count( $unused ),
			'unused_classes'                     => $unused,
			'stylesheets_scanned'                 => $stylesheets_scanned,
			'oxygen_stylesheet_filter_matched'    => $filter_matched,
			'cache_headers_seen'                  => $cache_headers,
			'possible_stale_content'              => artivio_oxygen_audit_looks_stale( $cache_headers ),
		),
		200
	);
}
