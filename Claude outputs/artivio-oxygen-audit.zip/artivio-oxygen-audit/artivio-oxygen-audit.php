<?php
/**
 * Plugin Name:       Artivio Oxygen Audit
 * Description:       Read-only diagnostic endpoints for AI agents editing Oxygen Builder pages. Answers the question "did my class/style edit actually take effect on the live page?" without needing a browser. Built after repeated incidents where an agent (Theo) reported a page "fixed" while classes were silently detached from their CSS rules, or duplicate CSS from earlier rebuild attempts sat unused in the stylesheet. See the two endpoints below.
 * Version:           1.0.0
 * Author:            Artivio
 * Requires PHP:      7.4
 *
 * ---------------------------------------------------------------------------
 * WHAT THIS PLUGIN IS FOR
 * ---------------------------------------------------------------------------
 * Oxygen Builder elements carry classes (e.g. "ba-off-white-section"), and
 * those classes only mean something if a matching CSS rule exists AND is
 * actually attached to the element. Nothing in the normal Oxygen MCP toolset
 * verifies that pairing after an edit. An agent can successfully write a
 * class onto an element, get a "zero issues" result from a layout/overflow
 * checker, and still ship a page where the class does nothing (typo'd, or
 * the CSS rule for it was never written, or it was written for a different
 * page and never wired up here).
 *
 * This plugin exposes two REST endpoints that do real, callable, structural
 * analysis of a LIVE rendered page (not the builder's internal JSON), so an
 * agent can self-check before declaring a fix done:
 *
 *   GET /wp-json/artivio-oxygen-audit/v1/audit-page/{post_id}
 *     -> Per-element class list + which of the element's own classes
 *        actually declare background-color / padding / color, and which
 *        classes on the element don't exist in any loaded stylesheet at all
 *        (the "typo'd class name" case).
 *
 *   GET /wp-json/artivio-oxygen-audit/v1/unused-classes/{post_id}
 *     -> Every class-based CSS rule found in the page's stylesheets that
 *        currently matches ZERO elements on the page. This surfaces CSS
 *        that already exists (often from an earlier rebuild attempt) and
 *        can be reused by name, instead of an agent guessing at or writing
 *        brand new class names/rules.
 *
 *   GET /wp-json/artivio-oxygen-audit/v1/status
 *     -> Simple health check (version, WP/Oxygen theme info) for wiring
 *        this into an MCP ability schema.
 *
 * ---------------------------------------------------------------------------
 * HONEST LIMITATIONS (read before trusting this blindly)
 * ---------------------------------------------------------------------------
 * This is deliberately a lightweight static-analysis tool, NOT a headless
 * browser and NOT a real CSS cascade engine. Specifically it does NOT:
 *   - Resolve specificity, !important, or rule ORDER precisely (it reports
 *     "a rule declaring this property exists for this class" — if two
 *     classes on the same element conflict, this tool won't tell you which
 *     one visually wins).
 *   - Evaluate @media queries conditionally — a rule inside a
 *     "max-width: 767px" block is still counted as "this class has a
 *     background-color rule", even though it only applies on mobile.
 *   - Resolve inherited values from ancestor elements. An element with no
 *     background of its own is flagged as such even if that's intentional
 *     (e.g. it's meant to show its parent's background through).
 *   - Understand selectors more complex than ".class" or ".class tag"
 *     (no ids, attribute selectors, multi-class chains, pseudo-classes,
 *     nested combinators). Those rules are still counted for the
 *     "is this class referenced anywhere in CSS" unused-class check, just
 *     not for the per-property matching in audit-page.
 *
 * Treat a flag from this tool as "look here first", not as ground truth.
 * For anything it flags as fine, a live visual check is still worthwhile
 * before calling a fix done — this narrows where to look, it doesn't
 * replace looking.
 *
 * ---------------------------------------------------------------------------
 * WIRING THIS INTO THE EXISTING wp-mcp / Oxygen ability layer
 * ---------------------------------------------------------------------------
 * This plugin does not itself register MCP abilities — it only exposes
 * plain WordPress REST routes, authenticated the same way the rest of the
 * wp-mcp toolset presumably already authenticates (WP Application
 * Passwords / cookie auth + capability check). Whoever maintains the
 * wp-mcp bridge should add two new abilities that simply call these
 * routes and pass the JSON straight through, e.g.:
 *
 *   oxygen-audit-page      { post_id }  -> GET .../audit-page/{post_id}
 *   oxygen-find-unused-classes { post_id } -> GET .../unused-classes/{post_id}
 *
 * Suggested playbook rule once wired up: after any edit that touches
 * classes, layout, or styling on an Oxygen page, call oxygen-audit-page
 * before reporting the fix as done, and call oxygen-find-unused-classes
 * BEFORE writing new CSS for a section that looks unstyled — there is
 * a real chance a matching class already exists from an earlier attempt.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'ARTIVIO_OXYGEN_AUDIT_VERSION', '1.0.0' );
define( 'ARTIVIO_OXYGEN_AUDIT_NS', 'artivio-oxygen-audit/v1' );

add_action( 'rest_api_init', 'artivio_oxygen_audit_register_routes' );

/**
 * Register the plugin's REST routes.
 */
function artivio_oxygen_audit_register_routes() {
	register_rest_route(
		ARTIVIO_OXYGEN_AUDIT_NS,
		'/status',
		array(
			'methods'             => 'GET',
			'callback'            => 'artivio_oxygen_audit_status',
			'permission_callback' => 'artivio_oxygen_audit_permission_check',
		)
	);

	register_rest_route(
		ARTIVIO_OXYGEN_AUDIT_NS,
		'/audit-page/(?P<id>\d+)',
		array(
			'methods'             => 'GET',
			'callback'            => 'artivio_oxygen_audit_page',
			'permission_callback' => 'artivio_oxygen_audit_permission_check',
			'args'                => array(
				'id' => array(
					'validate_callback' => function ( $param ) {
						return is_numeric( $param );
					},
				),
			),
		)
	);

	register_rest_route(
		ARTIVIO_OXYGEN_AUDIT_NS,
		'/unused-classes/(?P<id>\d+)',
		array(
			'methods'             => 'GET',
			'callback'            => 'artivio_oxygen_audit_unused_classes',
			'permission_callback' => 'artivio_oxygen_audit_permission_check',
			'args'                => array(
				'id' => array(
					'validate_callback' => function ( $param ) {
						return is_numeric( $param );
					},
				),
			),
		)
	);
}

/**
 * Shared permission check: same bar as editing the page (Application
 * Passwords over Basic Auth resolve to a real WP user, so this works the
 * same way any other authenticated wp-mcp call already does).
 */
function artivio_oxygen_audit_permission_check() {
	return current_user_can( 'edit_posts' );
}

/**
 * GET /status
 */
function artivio_oxygen_audit_status( WP_REST_Request $request ) {
	return new WP_REST_Response(
		array(
			'plugin_version' => ARTIVIO_OXYGEN_AUDIT_VERSION,
			'wp_version'     => get_bloginfo( 'version' ),
			'active_theme'   => wp_get_theme()->get( 'Name' ),
			'site_url'       => site_url(),
		),
		200
	);
}

/**
 * Fetch a post's live rendered HTML via an internal loopback request, plus
 * every stylesheet (external <link> and inline <style>) referenced on that
 * page. Returns [ $html, $css_text, $error ].
 */
function artivio_oxygen_audit_fetch_page( $post_id ) {
	$post = get_post( $post_id );
	if ( ! $post ) {
		return array( null, null, 'post_not_found' );
	}

	$url = get_permalink( $post_id );
	if ( ! $url ) {
		return array( null, null, 'no_permalink' );
	}

	// Cache-bust so we audit what's actually live right now, not a cached copy.
	$url = add_query_arg( 'artivio_audit_nocache', time(), $url );

	$response = wp_remote_get(
		$url,
		array(
			'timeout'   => 20,
			'sslverify' => false,
			'headers'   => array( 'Cache-Control' => 'no-cache' ),
		)
	);

	if ( is_wp_error( $response ) ) {
		return array( null, null, 'fetch_failed: ' . $response->get_error_message() );
	}

	$html = wp_remote_retrieve_body( $response );
	if ( empty( $html ) ) {
		return array( null, null, 'empty_response' );
	}

	$css_text = artivio_oxygen_audit_collect_css( $html, $url );

	return array( $html, $css_text, null );
}

/**
 * Pull every stylesheet's text out of a page: inline <style> blocks plus
 * every <link rel="stylesheet"> fetched over HTTP.
 */
function artivio_oxygen_audit_collect_css( $html, $base_url ) {
	$css_chunks = array();

	libxml_use_internal_errors( true );
	$dom = new DOMDocument();
	$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html );
	libxml_clear_errors();

	// Inline <style> tags.
	foreach ( $dom->getElementsByTagName( 'style' ) as $style_node ) {
		$css_chunks[] = $style_node->textContent;
	}

	// External stylesheets.
	foreach ( $dom->getElementsByTagName( 'link' ) as $link_node ) {
		$rel = strtolower( (string) $link_node->getAttribute( 'rel' ) );
		if ( 'stylesheet' !== $rel ) {
			continue;
		}
		$href = $link_node->getAttribute( 'href' );
		if ( empty( $href ) ) {
			continue;
		}
		if ( 0 === strpos( $href, '//' ) ) {
			$href = 'https:' . $href;
		} elseif ( 0 === strpos( $href, '/' ) ) {
			$parsed = wp_parse_url( $base_url );
			$href   = $parsed['scheme'] . '://' . $parsed['host'] . $href;
		}

		$css_response = wp_remote_get( $href, array( 'timeout' => 15, 'sslverify' => false ) );
		if ( ! is_wp_error( $css_response ) ) {
			$css_chunks[] = wp_remote_retrieve_body( $css_response );
		}
	}

	return implode( "\n", $css_chunks );
}

/**
 * Parse raw CSS text into a class -> declared-properties map.
 *
 * Only two selector shapes are understood:
 *   .foo             -> properties recorded directly against "foo"
 *   .foo tag         -> properties recorded against "foo" under a
 *                       "descendant_<tag>" bucket (e.g. descendant_h3)
 *
 * Everything else (ids, multi-class chains, attribute/pseudo selectors,
 * nested combinators) is skipped for property-matching, but the raw
 * selector text is still kept in $all_class_tokens so the unused-classes
 * report doesn't produce false positives for classes that ARE referenced,
 * just via a selector shape this parser doesn't fully understand.
 */
function artivio_oxygen_audit_parse_css( $css_text ) {
	$class_props     = array(); // class => [ property => [ rule_text, ... ] ]
	$all_class_tokens = array(); // every class name seen in ANY selector, for unused-class purposes.

	// Strip comments.
	$css_text = preg_replace( '!/\*.*?\*/!s', '', $css_text );

	// Match "selector_list { declarations }" blocks. This intentionally
	// does not track @media nesting depth — a rule inside @media is still
	// picked up (see plugin header: limitation, not a bug).
	if ( ! preg_match_all( '/([^{}]+)\{([^{}]*)\}/s', $css_text, $matches, PREG_SET_ORDER ) ) {
		return array( $class_props, $all_class_tokens );
	}

	foreach ( $matches as $match ) {
		$selector_list = trim( $match[1] );
		$declarations  = trim( $match[2] );

		if ( '' === $selector_list || '' === $declarations || 0 === strpos( $selector_list, '@' ) ) {
			continue;
		}

		// Record every bare class token mentioned anywhere in this selector
		// list, regardless of shape, for the unused-classes check.
		if ( preg_match_all( '/\.([a-zA-Z0-9_-]+)/', $selector_list, $class_hits ) ) {
			foreach ( $class_hits[1] as $cls ) {
				$all_class_tokens[ $cls ] = true;
			}
		}

		// Parse declared property names once for this block.
		$props = array();
		foreach ( explode( ';', $declarations ) as $decl ) {
			$decl = trim( $decl );
			if ( '' === $decl || false === strpos( $decl, ':' ) ) {
				continue;
			}
			list( $prop ) = explode( ':', $decl, 2 );
			$props[]      = strtolower( trim( $prop ) );
		}
		if ( empty( $props ) ) {
			continue;
		}

		foreach ( explode( ',', $selector_list ) as $selector ) {
			$selector = trim( $selector );

			// Shape 1: exact single class, e.g. ".ba-card"
			if ( preg_match( '/^\.([a-zA-Z0-9_-]+)$/', $selector, $m ) ) {
				$cls = $m[1];
				foreach ( $props as $prop ) {
					$class_props[ $cls ][ $prop ][] = trim( $selector_list ) . ' { ' . trim( $declarations ) . ' }';
				}
				continue;
			}

			// Shape 2: single class + descendant tag, e.g. ".hww-who-card h3"
			if ( preg_match( '/^\.([a-zA-Z0-9_-]+)\s+([a-zA-Z][a-zA-Z0-9]*)$/', $selector, $m ) ) {
				$cls    = $m[1];
				$bucket = 'descendant_' . strtolower( $m[2] );
				foreach ( $props as $prop ) {
					$class_props[ $cls ][ $bucket . ':' . $prop ][] = trim( $selector_list ) . ' { ' . trim( $declarations ) . ' }';
				}
				continue;
			}
			// Anything more complex: not matched for property-mapping,
			// already counted in $all_class_tokens above.
		}
	}

	return array( $class_props, $all_class_tokens );
}

/**
 * The properties we specifically check for per element, because these are
 * exactly the ones behind every incident so far: a section with no
 * background, or text with no color (invisible against its background).
 */
function artivio_oxygen_audit_watched_properties() {
	return array( 'background-color', 'background', 'padding', 'color' );
}

/**
 * GET /audit-page/{id}
 */
function artivio_oxygen_audit_page( WP_REST_Request $request ) {
	$post_id = (int) $request['id'];

	list( $html, $css_text, $error ) = artivio_oxygen_audit_fetch_page( $post_id );
	if ( $error ) {
		return new WP_REST_Response( array( 'error' => $error ), 400 );
	}

	list( $class_props, $all_class_tokens ) = artivio_oxygen_audit_parse_css( $css_text );
	$watched = artivio_oxygen_audit_watched_properties();

	libxml_use_internal_errors( true );
	$dom = new DOMDocument();
	$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html );
	libxml_clear_errors();

	$xpath    = new DOMXPath( $dom );
	$elements = $xpath->query( '//*[@class]' );

	$results        = array();
	$flagged_count  = 0;

	foreach ( $elements as $el ) {
		$class_attr = trim( $el->getAttribute( 'class' ) );
		if ( '' === $class_attr ) {
			continue;
		}
		$classes = preg_split( '/\s+/', $class_attr );

		// Skip Oxygen's own auto-generated structural classes
		// (oxy-container-xxxx-yyy, oxy-text-xxxx-yyy) for the "unknown
		// class" check — those are always valid, just not stylesheet-defined
		// by name; only check the human-authored classes alongside them.
		$checkable_classes = array_filter(
			$classes,
			function ( $c ) {
				return ! preg_match( '/^oxy-(container|text|text-link)-\d+-\d+$/', $c )
					&& 'oxy-container' !== $c && 'oxy-text' !== $c && 'oxy-text-link' !== $c;
			}
		);

		if ( empty( $checkable_classes ) ) {
			continue;
		}

		$unknown_classes = array();
		$has_property    = array();
		foreach ( $watched as $prop ) {
			$has_property[ $prop ] = false;
		}
		$evidence = array();

		foreach ( $checkable_classes as $cls ) {
			if ( ! isset( $all_class_tokens[ $cls ] ) ) {
				$unknown_classes[] = $cls;
				continue;
			}
			if ( isset( $class_props[ $cls ] ) ) {
				foreach ( $watched as $prop ) {
					if ( isset( $class_props[ $cls ][ $prop ] ) ) {
						$has_property[ $prop ] = true;
						$evidence[]            = $class_props[ $cls ][ $prop ][0];
					}
				}
			}
		}

		$missing = array_keys( array_filter( $has_property, function ( $v ) {
			return ! $v;
		} ) );

		// Only surface elements that actually need a look: an unknown
		// (typo'd/undefined) class, or an element with visible text/is a
		// container-like tag that has NONE of the watched properties from
		// its own classes.
		$tag_lc         = strtolower( $el->tagName );
		$is_container   = in_array( $tag_lc, array( 'section', 'div' ), true );
		$is_text_bearer = in_array( $tag_lc, array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'span', 'a', 'li' ), true );
		$has_text       = '' !== trim( $el->textContent );

		$noteworthy = ! empty( $unknown_classes )
			|| ( $is_container && ! $has_property['background-color'] && ! $has_property['background'] )
			|| ( $is_text_bearer && $has_text && ! $has_property['color'] );

		if ( ! $noteworthy ) {
			continue;
		}

		$flagged_count++;
		$results[] = array(
			'tag'              => $tag_lc,
			'classes'          => array_values( $classes ),
			'text_preview'     => mb_substr( trim( preg_replace( '/\s+/', ' ', $el->textContent ) ), 0, 60 ),
			'unknown_classes'  => array_values( $unknown_classes ),
			'missing_from_own_classes' => array_values( $missing ),
			'note'             => 'Flagged heuristically — check ancestors before assuming this is broken (see plugin limitations).',
		);
	}

	return new WP_REST_Response(
		array(
			'post_id'        => $post_id,
			'audited_url'    => get_permalink( $post_id ),
			'elements_flagged' => $flagged_count,
			'flags'          => $results,
			'limitations'    => 'Heuristic static analysis: no cascade/specificity resolution, no media-query awareness, no ancestor inheritance. See plugin header docblock.',
		),
		200
	);
}

/**
 * GET /unused-classes/{id}
 */
function artivio_oxygen_audit_unused_classes( WP_REST_Request $request ) {
	$post_id = (int) $request['id'];

	list( $html, $css_text, $error ) = artivio_oxygen_audit_fetch_page( $post_id );
	if ( $error ) {
		return new WP_REST_Response( array( 'error' => $error ), 400 );
	}

	list( $class_props, $all_class_tokens ) = artivio_oxygen_audit_parse_css( $css_text );

	libxml_use_internal_errors( true );
	$dom = new DOMDocument();
	$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html );
	libxml_clear_errors();

	$xpath        = new DOMXPath( $dom );
	$elements     = $xpath->query( '//*[@class]' );
	$used_classes = array();

	foreach ( $elements as $el ) {
		$class_attr = trim( $el->getAttribute( 'class' ) );
		if ( '' === $class_attr ) {
			continue;
		}
		foreach ( preg_split( '/\s+/', $class_attr ) as $cls ) {
			$used_classes[ $cls ] = true;
		}
	}

	$unused = array();
	foreach ( $all_class_tokens as $cls => $_true ) {
		if ( isset( $used_classes[ $cls ] ) ) {
			continue;
		}
		$snippets = array();
		if ( isset( $class_props[ $cls ] ) ) {
			foreach ( $class_props[ $cls ] as $prop => $rules ) {
				$snippets[] = $rules[0];
			}
		}
		$unused[] = array(
			'class'    => $cls,
			'rules'    => array_slice( array_unique( $snippets ), 0, 5 ),
			'meaning'  => 'This class has a CSS rule but is not applied to any element currently on this page — likely leftover from an earlier build attempt. Consider reusing it by name before writing a new class.',
		);
	}

	// Most useful ones first: classes with recorded rule text.
	usort(
		$unused,
		function ( $a, $b ) {
			return count( $b['rules'] ) <=> count( $a['rules'] );
		}
	);

	return new WP_REST_Response(
		array(
			'post_id'          => $post_id,
			'audited_url'      => get_permalink( $post_id ),
			'unused_class_count' => count( $unused ),
			'unused_classes'   => $unused,
		),
		200
	);
}
