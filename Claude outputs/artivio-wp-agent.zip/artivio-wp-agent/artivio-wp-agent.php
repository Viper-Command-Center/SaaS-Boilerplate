<?php
/**
 * Plugin Name:  Artivio WP Agent (base)
 * Plugin URI:   https://artivio.io
 * Description:  Builder-agnostic base plugin for Artivio. Repairs WordPress Application Passwords on CGI/FastCGI hosts, exposes a self-diagnosing auth check, reports what a site actually runs, and reads/writes SEO fields for Rank Math, Yoast, SEOPress, or Slim SEO. Install on every client WordPress site regardless of page builder.
 * Version:      1.3.0
 * Requires PHP: 7.4
 * Author:       Artivio
 * License:      GPL-2.0-or-later
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * CHANGELOG
 *
 * 1.3.0 (2026-09-11) — Slim SEO support added. Ryan replaced SEOPress with Slim
 * SEO on the Gutenberg/Kadence build line; this route previously 409'd there
 * ("no supported SEO plugin") because Slim SEO wasn't in the detection list.
 * Slim SEO is architecturally different from the other three: it stores every
 * field as ONE JSON object in a single postmeta key (`slim_seo`) instead of one
 * meta key per field, so it can't use the flat field→meta-key map the other
 * three share. Added a dedicated read/write path (artivio_wp_slimseo_read() /
 * artivio_wp_slimseo_patch()) that reads/rewrites that JSON object, while
 * keeping the same caller-facing field names (title, description, canonical,
 * ogImage, twitterImage, noindex) so nothing else about the API changes. Slim
 * SEO's schema has no focusKeyword/breadcrumbTitle/ogTitle/ogDescription/
 * twitterTitle/twitterDescription/nofollow — sending those is reported back in
 * `ignoredFields`/`warnings` exactly like an unsupported field on any other
 * plugin, not silently dropped.
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * WHY THIS EXISTS SEPARATELY
 *
 * All of this was written inside artivio-elementor-agent, where it did not
 * belong. None of it is about Elementor:
 *
 *   · the Application Password repair is about PHP running as CGI/FastCGI
 *   · /authcheck answers "did my credential authenticate, and if not why"
 *   · Rank Math and Yoast store SEO in postmeta no matter what draws the page
 *
 * Leaving it there meant a Divi site — or a plain WordPress site, or a Bricks
 * site — would hit the exact silent auth failure that cost an afternoon on the
 * first Elementor install, with no diagnostic available, because the only copy
 * lived in a plugin nobody would install on a site with no Elementor.
 *
 * Install this on EVERY client site. Builder-specific plugins sit alongside it.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * COEXISTENCE
 *
 * artivio-elementor-agent 1.1.0+ carries its own copy of the auth shim. If both
 * are active, whichever loads first does the repair and the other must not
 * report a misleading result — see artivio_wp_bootstrap_basic_auth().
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ARTIVIO_WP_VERSION', '1.3.0' );
define( 'ARTIVIO_WP_NS', 'artivio/v1' );

/* ══════════════════════════════════════════════════════════════════════════
 * Application Password repair
 *
 * WordPress authenticates Application Passwords in
 * wp_authenticate_application_password(), which reads ONLY
 * $_SERVER['PHP_AUTH_USER'] and $_SERVER['PHP_AUTH_PW']. Apache with mod_php
 * fills those in. **PHP as CGI/FastCGI — LiteSpeed, PHP-FPM, most managed
 * hosts — does not.**
 *
 * The .htaccess line WordPress ships,
 *   RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]
 * only copies the header into an environment variable. Core never reads it
 * back, so the credential reaches the server, sits in $_SERVER, and is ignored.
 *
 * The failure is silent and badly misleading: the request is processed as
 * ANONYMOUS. Public reads keep working, so an integration looks healthy, while
 * anything needing auth returns "You are not currently logged in." That reads
 * like a wrong password and is not one.
 *
 * 🔒 THIS GRANTS NOTHING. It re-exposes to PHP a header the client already
 * sent, in the form PHP would have provided natively. WordPress still validates
 * the credential and a wrong one still fails. Only when PHP_AUTH_USER is
 * absent, and only for `Basic`.
 * ══════════════════════════════════════════════════════════════════════════ */

if ( ! function_exists( 'artivio_wp_bootstrap_basic_auth' ) ) {
	function artivio_wp_bootstrap_basic_auth(): void {
		/**
		 * Four states, because two collapse the cases that need opposite
		 * responses: "PHP handled it natively" and "no Authorization header
		 * arrived at all" are not the same event, and calling both `native`
		 * sends whoever is debugging to the wrong layer.
		 */
		$GLOBALS['artivio_auth_source'] = 'absent';

		/**
		 * If artivio-elementor-agent already ran ITS shim this request, adopt
		 * that verdict verbatim. Re-deriving it here would see the PHP_AUTH_USER
		 * the other plugin just set and report `native` — turning a correct
		 * "this server needed repair" into a confident lie, on the one field
		 * whose entire job is telling the truth about that.
		 */
		if ( isset( $GLOBALS['artivio_ea_auth_source'] ) ) {
			$GLOBALS['artivio_auth_source'] = (string) $GLOBALS['artivio_ea_auth_source'];
			return;
		}

		if ( ! empty( $_SERVER['PHP_AUTH_USER'] ) ) {
			$GLOBALS['artivio_auth_source'] = 'native';
			return;
		}

		$header = '';
		foreach (
			array(
				'HTTP_AUTHORIZATION',
				'REDIRECT_HTTP_AUTHORIZATION',
				'REDIRECT_REDIRECT_HTTP_AUTHORIZATION',
			) as $key
		) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				$header = trim( (string) $_SERVER[ $key ] );
				break;
			}
		}

		if ( '' === $header && function_exists( 'apache_request_headers' ) ) {
			foreach ( (array) apache_request_headers() as $k => $v ) {
				if ( 'authorization' === strtolower( (string) $k ) ) {
					$header = trim( (string) $v );
					break;
				}
			}
		}

		if ( '' === $header ) {
			return; // stays 'absent' — nothing reached PHP at all.
		}
		if ( 0 !== stripos( $header, 'basic ' ) ) {
			$GLOBALS['artivio_auth_source'] = 'unusable';
			return;
		}

		$decoded = base64_decode( substr( $header, 6 ), true ); // phpcs:ignore
		if ( false === $decoded || false === strpos( $decoded, ':' ) ) {
			$GLOBALS['artivio_auth_source'] = 'unusable';
			return;
		}

		// Split at the FIRST colon: application passwords contain spaces but
		// never a colon, and a WordPress username cannot contain one either.
		list( $user, $pass ) = explode( ':', $decoded, 2 );
		if ( '' === $user ) {
			$GLOBALS['artivio_auth_source'] = 'unusable';
			return;
		}

		$_SERVER['PHP_AUTH_USER']       = $user;
		$_SERVER['PHP_AUTH_PW']         = $pass;
		$GLOBALS['artivio_auth_source'] = 'shim';
	}
}

// File scope: WordPress resolves the current user lazily, after plugins load,
// so this is early enough for core REST auth and for every plugin's routes.
artivio_wp_bootstrap_basic_auth();

/* ══════════════════════════════════════════════════════════════════════════
 * Helpers
 * ══════════════════════════════════════════════════════════════════════════ */

function artivio_wp_auth_source(): string {
	return isset( $GLOBALS['artivio_auth_source'] ) ? (string) $GLOBALS['artivio_auth_source'] : 'absent';
}

function artivio_wp_can_edit(): bool {
	return current_user_can( 'edit_posts' );
}

function artivio_wp_guard_post( int $post_id ) {
	if ( ! get_post( $post_id ) ) {
		return new WP_Error( 'artivio_wp_not_found', 'No post with that id.', array( 'status' => 404 ) );
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return new WP_Error( 'artivio_wp_forbidden', 'This user cannot edit that post.', array( 'status' => 403 ) );
	}
	return true;
}

/* ══════════════════════════════════════════════════════════════════════════
 * SEO (Rank Math / Yoast / SEOPress / Slim SEO)
 *
 * Builder-agnostic by nature — all four store their fields in postmeta
 * (Slim SEO as one JSON object under a single key, the other three as one
 * key per field — see artivio_wp_seo_map()), and core WP REST does not
 * reliably expose those keys by default. The API here is
 * deliberately plugin-NEUTRAL: callers send `title`, `description`,
 * `focusKeyword`… and this maps them onto whichever plugin the site runs. An
 * agent should not have to know that Rank Math spells it
 * `rank_math_description`, Yoast spells it `_yoast_wpseo_metadesc`, and
 * SEOPress spells it `_seopress_titles_desc`; that is exactly the per-site
 * detail it gets wrong.
 *
 * SEOPress added 2026-09-11 (Ryan replaced Rank Math with SEOPress on the
 * Gutenberg/Kadence build line — this plugin previously reported "no SEO
 * plugin" on those sites even though SEOPress was active and configured).
 *
 * 🔶 noindex/nofollow are deliberately NOT wired up for SEOPress below.
 * `_seopress_robots_index` / `_seopress_robots_follow` are documented as
 * "returns 'yes' when true" (seopress.org), but which state the field name
 * means — "yes, indexing is allowed" vs "yes, noindex is set" — was not
 * confirmed against a live post before writing this. Getting that backwards
 * would silently deindex a live client site, so `artivio_wp_patch_seo()`
 * below refuses the write and says why rather than guessing.
 * ══════════════════════════════════════════════════════════════════════════ */

function artivio_wp_seo_plugin(): string {
	if ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) ) {
		return 'rankmath';
	}
	if ( defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Options' ) ) {
		return 'yoast';
	}
	if ( defined( 'SEOPRESS_VERSION' ) ) {
		return 'seopress';
	}
	// Slim SEO defines SLIM_SEO_VER (not *_VERSION, unlike the other three —
	// confirmed against the plugin's own main file). class_exists() fallback
	// covers a build where the constant load order changes.
	if ( defined( 'SLIM_SEO_VER' ) || class_exists( 'SlimSEO\Container' ) ) {
		return 'slimseo';
	}
	return 'none';
}

/**
 * Why "none" — so the agent (and the human) get a cause, not a shrug.
 * Seen live 2026-09-06: Rank Math was installed and activated over WP-CLI,
 * `wp plugin list` said active, but web requests still loaded without it
 * because `active_plugins` was served from the persistent object cache.
 * A bare 409 sent the agent hunting for a version-compatibility bug that did
 * not exist. This tells it which of the three states the site is in.
 */
function artivio_wp_seo_none_error(): WP_Error {
	$candidates = array(
		'Rank Math' => 'seo-by-rank-math/rank-math.php',
		'Yoast SEO' => 'wordpress-seo/wp-seo.php',
		'SEOPress'  => 'wp-seopress/seopress.php',
		'Slim SEO'  => 'slim-seo/slim-seo.php',
	);
	$active_db  = (array) get_option( 'active_plugins', array() );
	$installed  = array();
	$listed     = array();
	foreach ( $candidates as $label => $file ) {
		if ( file_exists( WP_PLUGIN_DIR . '/' . $file ) ) {
			$installed[] = $label;
			if ( in_array( $file, $active_db, true ) ) {
				$listed[] = $label;
			}
		}
	}
	$install_slug = 'seo-by-rank-math';
	if ( in_array( 'Yoast SEO', $installed, true ) && ! in_array( 'Rank Math', $installed, true ) ) {
		$install_slug = 'wordpress-seo';
	} elseif ( in_array( 'SEOPress', $installed, true ) && ! in_array( 'Rank Math', $installed, true ) && ! in_array( 'Yoast SEO', $installed, true ) ) {
		$install_slug = 'wp-seopress';
	} elseif ( in_array( 'Slim SEO', $installed, true ) && ! in_array( 'Rank Math', $installed, true ) && ! in_array( 'Yoast SEO', $installed, true ) && ! in_array( 'SEOPress', $installed, true ) ) {
		$install_slug = 'slim-seo';
	}
	if ( $listed ) {
		$hint = implode( ', ', $listed ) . ' is in active_plugins but did not load in this request — the option is probably stale in the object cache. Run wp_cache_flush (or `wp cache flush`) and retry; if it persists, deactivate and reactivate the plugin.';
	} elseif ( $installed ) {
		$hint = implode( ', ', $installed ) . ' is installed but NOT active. Activate it (wp_cli ["plugin","activate","' . $install_slug . '"]) and retry.';
	} else {
		$hint = 'None of Rank Math, Yoast, SEOPress, or Slim SEO is installed. Install one (wp_cli ["plugin","install","seo-by-rank-math","--activate"]) and retry.';
	}
	return new WP_Error(
		'artivio_wp_no_seo_plugin',
		'No supported SEO plugin is loaded in this request. This route supports Rank Math, Yoast, SEOPress, and Slim SEO. ' . $hint,
		array(
			'status'      => 409,
			'installed'   => $installed,
			'activeInDb'  => $listed,
			'objectCache' => (bool) wp_using_ext_object_cache(),
		)
	);
}

function artivio_wp_seo_map( string $which ): array {
	if ( 'rankmath' === $which ) {
		return array(
			'title'              => 'rank_math_title',
			'description'        => 'rank_math_description',
			'focusKeyword'       => 'rank_math_focus_keyword',
			'canonical'          => 'rank_math_canonical_url',
			'breadcrumbTitle'    => 'rank_math_breadcrumb_title',
			'ogTitle'            => 'rank_math_facebook_title',
			'ogDescription'      => 'rank_math_facebook_description',
			'ogImage'            => 'rank_math_facebook_image',
			'twitterTitle'       => 'rank_math_twitter_title',
			'twitterDescription' => 'rank_math_twitter_description',
			'twitterImage'       => 'rank_math_twitter_image',
		);
	}
	if ( 'yoast' === $which ) {
		return array(
			'title'              => '_yoast_wpseo_title',
			'description'        => '_yoast_wpseo_metadesc',
			'focusKeyword'       => '_yoast_wpseo_focuskw',
			'canonical'          => '_yoast_wpseo_canonical',
			'breadcrumbTitle'    => '_yoast_wpseo_bctitle',
			'ogTitle'            => '_yoast_wpseo_opengraph-title',
			'ogDescription'      => '_yoast_wpseo_opengraph-description',
			'ogImage'            => '_yoast_wpseo_opengraph-image',
			'twitterTitle'       => '_yoast_wpseo_twitter-title',
			'twitterDescription' => '_yoast_wpseo_twitter-description',
			'twitterImage'       => '_yoast_wpseo_twitter-image',
		);
	}
	if ( 'seopress' === $which ) {
		// Per seopress.org's own "list of all post metas" doc (confirmed
		// 2026-09-11). focusKeyword is comma-separated in SEOPress, unlike
		// Rank Math/Yoast's single keyword — read/written as-is, a caller
		// wanting multiple keywords sends them comma-separated.
		return array(
			'title'              => '_seopress_titles_title',
			'description'        => '_seopress_titles_desc',
			'focusKeyword'       => '_seopress_analysis_target_kw',
			'canonical'          => '_seopress_robots_canonical',
			'ogTitle'            => '_seopress_social_fb_title',
			'ogDescription'      => '_seopress_social_fb_desc',
			'ogImage'            => '_seopress_social_fb_img',
			'twitterTitle'       => '_seopress_social_twitter_title',
			'twitterDescription' => '_seopress_social_twitter_desc',
			'twitterImage'       => '_seopress_social_twitter_img',
			// No breadcrumbTitle equivalent confirmed for SEOPress — omitted
			// rather than guessed.
		);
	}
	if ( 'slimseo' === $which ) {
		// Slim SEO stores its fields as ONE JSON object in a single postmeta
		// key (`slim_seo`), confirmed against elightup/slim-seo's own
		// src/RestApi.php schema (2026-09-11) — not one meta key per field
		// like the other three plugins. This map is still used to decide
		// which caller-facing field NAMES this plugin accepts and what its
		// sub-key is called inside that JSON object; artivio_wp_slimseo_read()
		// and artivio_wp_slimseo_patch() do the actual read/write against the
		// single key rather than looping this map through get/update_post_meta
		// like the other three. Slim SEO's schema has no focusKeyword,
		// breadcrumbTitle, ogTitle, ogDescription, twitterTitle, or
		// twitterDescription — omitted, same as SEOPress's breadcrumbTitle gap.
		return array(
			'title'        => 'title',
			'description'  => 'description',
			'canonical'    => 'canonical',
			'ogImage'      => 'facebook_image',
			'twitterImage' => 'twitter_image',
		);
	}
	return array();
}

function artivio_wp_seo_url_fields(): array {
	return array( 'canonical', 'ogImage', 'twitterImage' );
}

/** Google truncates around here. We REPORT rather than truncate: silently
 *  cutting a client's meta description is worse than a long one. */
function artivio_wp_seo_limits(): array {
	return array(
		'title'       => 60,
		'description' => 155,
	);
}

/**
 * Slim SEO-only read: unpacks the single `slim_seo` JSON postmeta object
 * instead of looping artivio_wp_seo_map() through get_post_meta() per field,
 * because there is no per-field meta key to loop over.
 */
function artivio_wp_slimseo_read( int $post_id ): array {
	$raw = get_post_meta( $post_id, 'slim_seo', true );
	$raw = is_array( $raw ) ? $raw : array();
	$out = array();
	foreach ( artivio_wp_seo_map( 'slimseo' ) as $field => $subkey ) {
		$out[ $field ] = isset( $raw[ $subkey ] ) ? $raw[ $subkey ] : '';
	}
	$out['noindex'] = ! empty( $raw['noindex'] );
	return $out;
}

function artivio_wp_seo_read( int $post_id, string $which ): array {
	if ( 'slimseo' === $which ) {
		return artivio_wp_slimseo_read( $post_id );
	}
	$out = array();
	foreach ( artivio_wp_seo_map( $which ) as $field => $key ) {
		$out[ $field ] = get_post_meta( $post_id, $key, true );
	}
	if ( 'rankmath' === $which ) {
		$robots          = get_post_meta( $post_id, 'rank_math_robots', true );
		$robots          = is_array( $robots ) ? $robots : array();
		$out['noindex']  = in_array( 'noindex', $robots, true );
		$out['nofollow'] = in_array( 'nofollow', $robots, true );
	} elseif ( 'yoast' === $which ) {
		$out['noindex']  = '1' === (string) get_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', true );
		$out['nofollow'] = '1' === (string) get_post_meta( $post_id, '_yoast_wpseo_meta-robots-nofollow', true );
	}
	// 'seopress': noindex/nofollow deliberately omitted — see the note above
	// artivio_wp_seo_plugin(). Reading them back would need the same
	// unconfirmed value-direction as writing them.
	return $out;
}

function artivio_wp_get_seo( WP_REST_Request $r ) {
	$post_id = (int) $r['id'];
	$guard   = artivio_wp_guard_post( $post_id );
	if ( is_wp_error( $guard ) ) {
		return $guard;
	}
	$which = artivio_wp_seo_plugin();
	if ( 'none' === $which ) {
		return artivio_wp_seo_none_error();
	}
	$values = artivio_wp_seo_read( $post_id, $which );
	return array(
		'id'        => $post_id,
		'seoPlugin' => $which,
		'fields'    => $values,
		'lengths'   => array(
			'title'       => mb_strlen( (string) ( $values['title'] ?? '' ) ),
			'description' => mb_strlen( (string) ( $values['description'] ?? '' ) ),
		),
		'limits'    => artivio_wp_seo_limits(),
		'postTitle' => get_the_title( $post_id ),
		'link'      => get_permalink( $post_id ),
		'note'      => 'An EMPTY title or description does not mean nothing is output — it means the SEO plugin falls back to its own template. Setting a value overrides that template for this page only.',
	);
}

/**
 * Slim SEO-only write: rewrites the single `slim_seo` JSON postmeta object
 * rather than calling update_post_meta() once per field like the other three
 * plugins, since Slim SEO has no per-field meta key to update. Reads the
 * existing object first so an untouched field already stored there survives
 * a write that only sets one or two fields (a per-key update_post_meta call
 * never had this problem because each field lived in its own key).
 */
function artivio_wp_slimseo_patch( int $post_id, WP_REST_Request $r ) {
	$map     = artivio_wp_seo_map( 'slimseo' );
	$urls    = artivio_wp_seo_url_fields();
	$limits  = artivio_wp_seo_limits();
	$changed = array();
	$cleared = array();
	$warn    = array();
	$unknown = array();

	$raw = get_post_meta( $post_id, 'slim_seo', true );
	$raw = is_array( $raw ) ? $raw : array();

	$params = $r->get_params();
	foreach ( $params as $field => $value ) {
		if ( 'id' === $field ) {
			continue;
		}
		if ( 'noindex' === $field ) {
			$raw['noindex'] = filter_var( $value, FILTER_VALIDATE_BOOLEAN );
			$changed[]      = 'noindex';
			continue;
		}
		if ( 'nofollow' === $field ) {
			// Slim SEO's own schema (src/RestApi.php) has no nofollow flag —
			// only noindex. Reported rather than silently dropped.
			$warn[] = 'nofollow is not part of Slim SEO\'s schema (only noindex exists) — ignored.';
			continue;
		}
		if ( ! isset( $map[ $field ] ) ) {
			$unknown[] = $field;
			continue;
		}
		$subkey = $map[ $field ];

		if ( null === $value || '' === $value ) {
			unset( $raw[ $subkey ] );
			$cleared[] = $field;
			continue;
		}

		$clean = in_array( $field, $urls, true )
			? esc_url_raw( (string) $value )
			: sanitize_text_field( (string) $value );

		if ( isset( $limits[ $field ] ) && mb_strlen( $clean ) > $limits[ $field ] ) {
			$warn[] = sprintf(
				'%s is %d characters; Google typically truncates beyond about %d. Saved as supplied.',
				$field,
				mb_strlen( $clean ),
				$limits[ $field ]
			);
		}

		$raw[ $subkey ] = $clean;
		$changed[]      = $field;
	}

	update_post_meta( $post_id, 'slim_seo', wp_slash( $raw ) );
	clean_post_cache( $post_id );

	return array(
		'id'            => $post_id,
		'seoPlugin'     => 'slimseo',
		'changed'       => $changed,
		'cleared'       => $cleared,
		'ignoredFields' => $unknown,
		'warnings'      => $warn,
		'fields'        => artivio_wp_slimseo_read( $post_id ),
		'link'          => get_permalink( $post_id ),
	);
}

function artivio_wp_patch_seo( WP_REST_Request $r ) {
	$post_id = (int) $r['id'];
	$guard   = artivio_wp_guard_post( $post_id );
	if ( is_wp_error( $guard ) ) {
		return $guard;
	}
	$which = artivio_wp_seo_plugin();
	if ( 'none' === $which ) {
		return artivio_wp_seo_none_error();
	}
	if ( 'slimseo' === $which ) {
		return artivio_wp_slimseo_patch( $post_id, $r );
	}

	$map     = artivio_wp_seo_map( $which );
	$urls    = artivio_wp_seo_url_fields();
	$limits  = artivio_wp_seo_limits();
	$changed = array();
	$cleared = array();
	$warn    = array();
	$unknown = array();

	$params = $r->get_params();
	foreach ( $params as $field => $value ) {
		if ( in_array( $field, array( 'id', 'noindex', 'nofollow' ), true ) ) {
			continue;
		}
		if ( ! isset( $map[ $field ] ) ) {
			// Silently ignoring an unrecognised field is how a caller ends up
			// believing it set something it did not.
			$unknown[] = $field;
			continue;
		}
		$key = $map[ $field ];

		if ( null === $value || '' === $value ) {
			delete_post_meta( $post_id, $key );
			$cleared[] = $field;
			continue;
		}

		$clean = in_array( $field, $urls, true )
			? esc_url_raw( (string) $value )
			: sanitize_text_field( (string) $value );

		if ( isset( $limits[ $field ] ) && mb_strlen( $clean ) > $limits[ $field ] ) {
			$warn[] = sprintf(
				'%s is %d characters; Google typically truncates beyond about %d. Saved as supplied.',
				$field,
				mb_strlen( $clean ),
				$limits[ $field ]
			);
		}

		update_post_meta( $post_id, $key, wp_slash( $clean ) );
		$changed[] = $field;
	}

	if ( array_key_exists( 'noindex', $params ) || array_key_exists( 'nofollow', $params ) ) {
		if ( 'seopress' === $which ) {
			// Refuse rather than guess: _seopress_robots_index/_follow are
			// documented as "returns 'yes' when true", but not which state
			// ("indexing allowed" vs "noindex is set") that maps to. Writing
			// the wrong direction here would silently deindex a live page.
			$warn[] = 'noindex/nofollow are not supported for SEOPress in this plugin yet — the meta value direction needs confirming against a live post before it can write safely. No robots change was made.';
		} else {
			$current  = artivio_wp_seo_read( $post_id, $which );
			$noindex  = array_key_exists( 'noindex', $params )
				? filter_var( $params['noindex'], FILTER_VALIDATE_BOOLEAN )
				: (bool) ( $current['noindex'] ?? false );
			$nofollow = array_key_exists( 'nofollow', $params )
				? filter_var( $params['nofollow'], FILTER_VALIDATE_BOOLEAN )
				: (bool) ( $current['nofollow'] ?? false );

			if ( 'rankmath' === $which ) {
				$robots = array( $noindex ? 'noindex' : 'index', $nofollow ? 'nofollow' : 'follow' );
				update_post_meta( $post_id, 'rank_math_robots', wp_slash( $robots ) );
			} else {
				// Yoast: '1' = noindex, '2' = index.
				update_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', $noindex ? '1' : '2' );
				update_post_meta( $post_id, '_yoast_wpseo_meta-robots-nofollow', $nofollow ? '1' : '0' );
			}
			$changed[] = 'robots';
		}
	}

	clean_post_cache( $post_id );

	return array(
		'id'            => $post_id,
		'seoPlugin'     => $which,
		'changed'       => $changed,
		'cleared'       => $cleared,
		'ignoredFields' => $unknown,
		'warnings'      => $warn,
		'fields'        => artivio_wp_seo_read( $post_id, $which ),
		'link'          => get_permalink( $post_id ),
	);
}

/* ══════════════════════════════════════════════════════════════════════════
 * Routes
 * ══════════════════════════════════════════════════════════════════════════ */

add_action( 'rest_api_init', 'artivio_wp_register_routes' );

function artivio_wp_register_routes() {
	/**
	 * The only UNAUTHENTICATED route, and it exists because every other route
	 * requires auth — so when auth is what's broken, none of them can say why.
	 * They can only 401, which looks identical whether the password was wrong or
	 * the header never arrived. Those need opposite fixes: one is a two-second
	 * change in a settings panel, the other is a hosting ticket.
	 *
	 * 🔒 Discloses nothing to an anonymous caller: no username, no roles, no
	 * site detail beyond the plugin version. Identity is returned ONLY when the
	 * request authenticated — and a caller that authenticated already holds the
	 * credential. It never echoes the credential back in any form.
	 */
	register_rest_route(
		ARTIVIO_WP_NS,
		'/authcheck',
		array(
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'callback'            => 'artivio_wp_authcheck',
		)
	);

	register_rest_route(
		ARTIVIO_WP_NS,
		'/site',
		array(
			'methods'             => 'GET',
			'permission_callback' => 'artivio_wp_can_edit',
			'callback'            => 'artivio_wp_site',
		)
	);

	/**
	 * Provisioning hook (Artivio Phase 34 §8). On a freshly cloned template
	 * site an ADMINISTRATOR (template admin over HTTP Basic, or WP-CLI) calls
	 * this once; it creates the agent user, mints an application password and
	 * returns { site_url, username, app_password } — pasted into Artivio's
	 * "Add site from provisioning token", the site is registered and tested in
	 * one step. The password is returned exactly once and never stored here.
	 */
	register_rest_route(
		ARTIVIO_WP_NS,
		'/provision-agent',
		array(
			'methods'             => 'POST',
			'permission_callback' => 'artivio_wp_can_manage',
			'callback'            => 'artivio_wp_provision_agent_rest',
		)
	);

	register_rest_route(
		ARTIVIO_WP_NS,
		'/documents/(?P<id>\d+)/seo',
		array(
			array(
				'methods'             => 'GET',
				'permission_callback' => 'artivio_wp_can_edit',
				'callback'            => 'artivio_wp_get_seo',
			),
			array(
				'methods'             => 'PATCH',
				'permission_callback' => 'artivio_wp_can_edit',
				'callback'            => 'artivio_wp_patch_seo',
			),
		)
	);
}

function artivio_wp_authcheck() {
	$source = artivio_wp_auth_source();
	$user   = wp_get_current_user();
	$authed = ( $user instanceof WP_User ) && $user->ID > 0;

	$supplied = isset( $_SERVER['PHP_AUTH_USER'] ) ? (string) $_SERVER['PHP_AUTH_USER'] : '';
	$secret   = isset( $_SERVER['PHP_AUTH_PW'] ) ? (string) $_SERVER['PHP_AUTH_PW'] : '';

	$ssl       = is_ssl();
	$forwarded = isset( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) ? (string) $_SERVER['HTTP_X_FORWARDED_PROTO'] : '';
	$available = function_exists( 'wp_is_application_passwords_available' )
		? (bool) wp_is_application_passwords_available()
		: null;
	$in_use = class_exists( 'WP_Application_Passwords' ) && method_exists( 'WP_Application_Passwords', 'is_in_use' )
		? (bool) WP_Application_Passwords::is_in_use()
		: null;

	/**
	 * Ask WordPress itself rather than guessing. Re-running the
	 * application-password authenticator returns core's OWN error code, which
	 * names the actual cause — wrong username, wrong password, disabled for the
	 * site, disabled for that user. It is the same evaluation WordPress already
	 * performed for this request, so it grants nothing and reveals nothing a
	 * caller holding the credential could not learn by retrying.
	 */
	$core_reason = '';
	if ( ! $authed && '' !== $supplied && '' !== $secret && function_exists( 'wp_authenticate_application_password' ) ) {
		$attempt = wp_authenticate_application_password( null, $supplied, $secret );
		if ( is_wp_error( $attempt ) ) {
			$core_reason = $attempt->get_error_code() . ': ' . wp_strip_all_tags( (string) $attempt->get_error_message() );
		} elseif ( $attempt instanceof WP_User ) {
			$core_reason = 'unexpected — the credential VALIDATES when re-tested, so something else in the request rejected it (a security plugin, or a filter on determine_current_user).';
		} else {
			$core_reason = 'WordPress declined to evaluate the application password at all: neither a user nor an error, which means application passwords are unavailable here (see isSsl / appPasswordsAvailable) or a filter disabled them.';
		}
	}

	if ( $authed ) {
		$verdict = 'The credential AUTHENTICATED. If a tool still fails, the problem is that route or that user\'s capabilities, not the credential.';
	} elseif ( 'absent' === $source ) {
		$verdict = 'NO Authorization header reached PHP. The credential was never seen by WordPress, so this is not a wrong password and changing it will not help. Something between the client and PHP removed it — a proxy or CDN, or a server running PHP as CGI/FastCGI. This plugin repairs the CGI/FastCGI case automatically, so seeing "absent" means the header did not arrive at all: add "CGIPassAuth On" to .htaccess (Apache 2.4.13+ / LiteSpeed), or ask the host to forward the Authorization header.';
	} elseif ( 'unusable' === $source ) {
		$verdict = 'An Authorization header arrived but was not a decodable HTTP Basic credential. Artivio sends Basic, so something in front of this site is rewriting the header.';
	} elseif ( false === $available ) {
		$verdict = sprintf(
			'Application Passwords are UNAVAILABLE on this site, so WordPress refused to evaluate the credential at all — no password will work until this is fixed. WordPress gates them on HTTPS: is_ssl() reports %s%s. If the site is served over HTTPS but is_ssl() is false, a reverse proxy or CDN is terminating TLS and PHP cannot see it; the standard fix is to set $_SERVER[\'HTTPS\'] = \'on\' in wp-config.php when HTTP_X_FORWARDED_PROTO is https. A security plugin filtering wp_is_application_passwords_available does the same thing.',
			$ssl ? 'true' : 'false',
			'' !== $forwarded ? sprintf( ' while X-Forwarded-Proto is "%s"', $forwarded ) : ''
		);
	} elseif ( '' !== $core_reason ) {
		$verdict = sprintf(
			'A Basic credential reached WordPress and WordPress rejected it. Core\'s own reason: %s — for the username "%s" that was sent.',
			$core_reason,
			$supplied
		);
		/**
		 * The commonest mismatch of all, and WordPress's own UI causes it: the
		 * "New Application Password Name" field is a LABEL, shown in the Name
		 * column of that table. It looks like a username and is not one. People
		 * type that label as the username, get `invalid_username`, reasonably
		 * conclude the password is wrong, generate another, name it the same
		 * thing, and repeat.
		 */
		if ( 0 === strpos( $core_reason, 'invalid_username' ) ) {
			$verdict .= ' ⚠ Common cause: in WordPress, "New Application Password Name" is only a LABEL for the credential — it is NOT a username. The username is the account\'s login, shown in the Username column of Users → All Users, or that account\'s email address.';
		}
	} else {
		$verdict = sprintf(
			'A Basic credential reached WordPress for username "%s" and was rejected, but core reported no specific reason. Check the username matches the account the Application Password belongs to, and that it has not been revoked.',
			$supplied
		);
	}

	return array(
		'plugin'                => 'artivio-wp-agent',
		'pluginVersion'         => ARTIVIO_WP_VERSION,
		'authSource'            => $source,
		'authenticated'         => $authed,
		// Echoing back the username the CALLER sent is not disclosure — they
		// sent it — and it is the fastest way to catch the commonest fault:
		// the wrong username stored at the other end. The password is never
		// echoed in any form.
		'receivedUsername'      => '' !== $supplied ? $supplied : null,
		'isSsl'                 => $ssl,
		'forwardedProto'        => '' !== $forwarded ? $forwarded : null,
		'appPasswordsAvailable' => $available,
		'appPasswordsInUse'     => $in_use,
		'coreAuthError'         => '' !== $core_reason ? $core_reason : null,
		'user'                  => $authed ? $user->user_login : null,
		'roles'                 => $authed ? array_values( (array) $user->roles ) : array(),
		'canEditPosts'          => $authed ? current_user_can( 'edit_posts' ) : false,
		'verdict'               => $verdict,
	);
}

/**
 * What is this site, actually?
 *
 * Onboarding a new client used to mean guessing which builder and which SEO
 * plugin were in play, and guessing wrong is expensive: editing an Elementor
 * page through the plain WordPress tools succeeds and changes nothing. One call
 * answers it. Builder detection reads each plugin's own version constant, and
 * the REST namespace list shows which agent plugins are actually installed —
 * both read at runtime, so a site that changes tells the truth next call.
 */
function artivio_wp_site() {
	$user  = wp_get_current_user();
	$theme = wp_get_theme();

	$namespaces = array();
	if ( function_exists( 'rest_get_server' ) ) {
		$server = rest_get_server();
		if ( $server && method_exists( $server, 'get_namespaces' ) ) {
			$namespaces = array_values( (array) $server->get_namespaces() );
		}
	}

	$builders = array();
	if ( defined( 'ELEMENTOR_VERSION' ) ) {
		$builders['elementor'] = ELEMENTOR_VERSION;
	}
	if ( defined( 'ELEMENTOR_PRO_VERSION' ) ) {
		$builders['elementorPro'] = ELEMENTOR_PRO_VERSION;
	}
	if ( defined( 'ET_BUILDER_VERSION' ) ) {
		$builders['divi'] = ET_BUILDER_VERSION;
	}
	if ( defined( 'ET_CORE_VERSION' ) ) {
		$builders['diviCore'] = ET_CORE_VERSION;
	}
	if ( defined( 'BRICKS_VERSION' ) ) {
		$builders['bricks'] = BRICKS_VERSION;
	}
	if ( defined( 'FL_BUILDER_VERSION' ) ) {
		$builders['beaverBuilder'] = FL_BUILDER_VERSION;
	}
	// Oxygen: classic (CT_VERSION) and Oxygen 6+ (OXYGEN_VERSION / Breakdance-era constant).
	if ( defined( 'OXYGEN_VERSION' ) ) {
		$builders['oxygen'] = OXYGEN_VERSION;
	} elseif ( defined( 'CT_VERSION' ) ) {
		$builders['oxygen'] = CT_VERSION;
	}

	return array(
		'plugin'        => 'artivio-wp-agent',
		'pluginVersion' => ARTIVIO_WP_VERSION,
		'wp'            => get_bloginfo( 'version' ),
		'php'           => PHP_VERSION,
		'siteUrl'       => get_site_url(),
		'isSsl'         => is_ssl(),
		'authSource'    => artivio_wp_auth_source(),
		'theme'         => array(
			'name'     => $theme ? $theme->get( 'Name' ) : null,
			'version'  => $theme ? $theme->get( 'Version' ) : null,
			'template' => $theme ? $theme->get_template() : null,
		),
		'builders'      => $builders,
		'seoPlugin'     => artivio_wp_seo_plugin(),
		// Which agent plugins are reachable. artivio-elementor/v1 means the
		// Elementor agent is active; diviops/v1 means the DiviOps agent is.
		'restNamespaces' => array_slice( $namespaces, 0, 40 ),
		'user'          => $user ? $user->user_login : null,
		'roles'         => $user ? array_values( (array) $user->roles ) : array(),
		'note'          => 'Use `builders` to decide which connection edits layouts on this site. A page built with a builder cannot be edited through post_content — that write succeeds and changes nothing visible.',
	);
}

/**
 * Explain a 401/403 on OUR routes, in the response body.
 *
 * A rejected request never reaches a handler, so /site cannot report the one
 * case that most needs reporting: an Authorization header that never arrived.
 * WordPress renders that as `rest_forbidden` — indistinguishable from a wrong
 * password, which is exactly the confusion this plugin exists to end.
 */
function artivio_wp_annotate_auth_failure( $response, $server, $request ) {
	unset( $server );
	if ( ! ( $response instanceof WP_REST_Response ) || ! ( $request instanceof WP_REST_Request ) ) {
		return $response;
	}
	if ( 0 !== strpos( ltrim( (string) $request->get_route(), '/' ), 'artivio/' ) ) {
		return $response;
	}
	$status = $response->get_status();
	if ( 401 !== $status && 403 !== $status ) {
		return $response;
	}
	$data = $response->get_data();
	if ( ! is_array( $data ) ) {
		return $response;
	}

	$source = artivio_wp_auth_source();
	$hints  = array(
		'absent'   => 'PHP received NO Authorization header for this request. The credential was never seen, so this is not a wrong password. Something upstream removed it — a proxy, CDN, or a server passing PHP as CGI/FastCGI. Add "CGIPassAuth On" to .htaccess (Apache 2.4.13+ / LiteSpeed), or ask the host to forward the Authorization header.',
		'unusable' => 'An Authorization header arrived but was not a decodable HTTP Basic credential. Something in front of this site is rewriting it.',
		'native'   => 'The credential reached WordPress and WordPress rejected it. Wrong or revoked username/Application Password, or the user lacks edit_posts. Call /artivio/v1/authcheck for core\'s own reason.',
		'shim'     => 'The credential reached WordPress and WordPress rejected it. Wrong or revoked username/Application Password, or the user lacks edit_posts. Call /artivio/v1/authcheck for core\'s own reason.',
	);

	$data['artivioDiagnostic'] = array(
		'authSource' => $source,
		'hint'       => isset( $hints[ $source ] ) ? $hints[ $source ] : $hints['absent'],
	);
	$response->set_data( $data );
	return $response;
}
add_filter( 'rest_post_dispatch', 'artivio_wp_annotate_auth_failure', 10, 3 );

// ─── Provisioning (Phase 34 §8) ──────────────────────────────────────────────

function artivio_wp_can_manage(): bool {
	return current_user_can( 'manage_options' );
}

/**
 * Create (or reuse) the agent user and mint a fresh application password.
 * Returns array{site_url,username,app_password,label} or WP_Error.
 */
function artivio_wp_provision_agent( string $username = 'artivio-agent', string $email = '', string $label = '' ) {
	if ( ! class_exists( 'WP_Application_Passwords' ) ) {
		return new WP_Error( 'artivio_no_app_passwords', 'This WordPress does not support Application Passwords (needs 5.6+).', array( 'status' => 500 ) );
	}
	$username = sanitize_user( $username ?: 'artivio-agent', true );
	if ( '' === $username ) {
		return new WP_Error( 'artivio_bad_username', 'Invalid username.', array( 'status' => 400 ) );
	}
	$user = get_user_by( 'login', $username );
	if ( ! $user ) {
		$email = $email ? sanitize_email( $email ) : $username . '@' . wp_parse_url( home_url(), PHP_URL_HOST );
		$id    = wp_insert_user(
			array(
				'user_login'   => $username,
				'user_pass'    => wp_generate_password( 32, true, true ), // never used; app passwords only
				'user_email'   => $email,
				'display_name' => 'Artivio Agent',
				'role'         => 'administrator',
			)
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		$user = get_user_by( 'id', $id );
	} elseif ( ! in_array( 'administrator', (array) $user->roles, true ) ) {
		$user->set_role( 'administrator' );
	}

	$name    = 'artivio-provision-' . gmdate( 'Y-m-d-His' );
	$created = WP_Application_Passwords::create_new_application_password( $user->ID, array( 'name' => $name ) );
	if ( is_wp_error( $created ) ) {
		return $created;
	}
	list( $plain ) = $created;

	return array(
		'site_url'     => untrailingslashit( home_url() ),
		'username'     => $user->user_login,
		'app_password' => $plain,
		'label'        => $label,
		'note'         => 'Paste this JSON into Artivio → Tools → WordPress Sites → "Add from provisioning token". The password is shown once.',
	);
}

function artivio_wp_provision_agent_rest( WP_REST_Request $request ) {
	$result = artivio_wp_provision_agent(
		(string) $request->get_param( 'username' ),
		(string) $request->get_param( 'email' ),
		(string) $request->get_param( 'label' )
	);
	if ( is_wp_error( $result ) ) {
		return $result;
	}
	return new WP_REST_Response( $result, 201 );
}

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	/**
	 * `wp artivio provision-agent [--user=<login>] [--email=<email>] [--label=<label>]`
	 * Same hook for automation that clones sites over SSH. Prints the JSON once.
	 */
	WP_CLI::add_command(
		'artivio provision-agent',
		function ( $args, $assoc ) {
			$result = artivio_wp_provision_agent(
				isset( $assoc['user'] ) ? (string) $assoc['user'] : 'artivio-agent',
				isset( $assoc['email'] ) ? (string) $assoc['email'] : '',
				isset( $assoc['label'] ) ? (string) $assoc['label'] : ''
			);
			if ( is_wp_error( $result ) ) {
				WP_CLI::error( $result->get_error_message() );
			}
			WP_CLI::line( wp_json_encode( $result ) );
		}
	);
}
